import test from 'node:test';
import assert from 'node:assert/strict';
import {
  generateStandard32BarPlan,
  buildHardTechnoProtocolText,
} from './transition-protocol.ts';

test('generateStandard32BarPlan creates 3-step structured timeline', () => {
  const plan = generateStandard32BarPlan(
    { title: 'Sub Terror', bpm: 155, key: '8A' },
    { title: 'Acid Reactor', bpm: 156, key: '9A' },
    32
  );

  assert.equal(plan.durationBars, 32);
  assert.equal(plan.timelineSteps.length, 3);
  assert.equal(plan.timelineSteps[0].startBar, 1);
  assert.equal(plan.timelineSteps[0].endBar, 8);
  assert.equal(plan.timelineSteps[1].startBar, 9);
  assert.equal(plan.timelineSteps[1].endBar, 16);
  assert.equal(plan.timelineSteps[2].startBar, 17);
  assert.equal(plan.timelineSteps[2].endBar, 32);
});

test('buildHardTechnoProtocolText conforms to the required template format', () => {
  const plan = generateStandard32BarPlan(
    { title: 'Sub Terror', bpm: 155, key: '8A' },
    { title: 'Acid Reactor', bpm: 156, key: '9A' },
    32
  );

  const text = buildHardTechnoProtocolText(plan);

  assert.ok(text.includes('⚡ HARD TECHNO STEM & STRIPE ANALYSIS'));
  assert.ok(text.includes('Active Track: Sub Terror — BPM: 155 | Key: 8A'));
  assert.ok(text.includes('Target Track: Acid Reactor — BPM: 156 | Key: 9A'));
  assert.ok(text.includes('Touch Stripe Cue Points: Drop Cue 50.0%, Break Cue 25.0%, Outro Cue 87.5%'));
  assert.ok(text.includes('🎛️ WAVEFORM TOUCH STRIPE TRANSITION PROTOCOL'));
  assert.ok(text.includes('Transition Duration: 32 Bars / Touch-stripe Scrub to Bar 16 Drop'));
  assert.ok(text.includes('1. [Bar 1–8]:'));
  assert.ok(text.includes('2. [Bar 9–16]:'));
  assert.ok(text.includes('3. [Bar 17–32]:'));
  assert.ok(text.includes('💥 HARD FX & DRIVE EXECUTION'));
  assert.ok(text.includes('Filter & Drive:'));
  assert.ok(text.includes('Spatial Modulation:'));
});
