/**
 * High-BPM Automix & Bar Quantization Logic
 * Pure calculations decoupled for ultra-fast unit testing
 */

export interface BarPosition {
  bar: number; // 1-indexed
  beat: number; // 1 to 4
  sixteenth: number; // 1 to 4
  barProgress: number; // 0.0 to 1.0
  phrase32Progress: number; // 0.0 to 1.0
  totalSeconds: number;
}

/**
 * Calculates duration of a single beat in seconds.
 */
export function bpmToSecondsPerBeat(bpm: number): number {
  if (bpm <= 0) return 0.5; // fallback
  return 60 / bpm;
}

/**
 * Calculates duration of a full bar (measure) in 4/4 time.
 */
export function bpmToSecondsPerBar(bpm: number, beatsPerBar = 4): number {
  return bpmToSecondsPerBeat(bpm) * beatsPerBar;
}

/**
 * Calculates human-readable Bar.Beat.Sixteenth position from current elapsed seconds.
 */
export function calculateBarPosition(
  currentTimeSec: number,
  bpm: number,
  beatsPerBar = 4
): BarPosition {
  const safeTime = Math.max(0, currentTimeSec);
  const secPerBeat = bpmToSecondsPerBeat(bpm);
  const secPerBar = secPerBeat * beatsPerBar;
  const secPerSixteenth = secPerBeat / 4;

  const totalBarsFloat = safeTime / secPerBar;
  const barIndex = Math.floor(totalBarsFloat); // 0-based
  const barRemainderSec = safeTime % secPerBar;

  const beatIndex = Math.floor(barRemainderSec / secPerBeat); // 0 to 3
  const beatRemainderSec = barRemainderSec % secPerBeat;

  const sixteenthIndex = Math.floor(beatRemainderSec / secPerSixteenth); // 0 to 3

  const bar = barIndex + 1;
  const beat = beatIndex + 1;
  const sixteenth = sixteenthIndex + 1;

  const barProgress = (safeTime % secPerBar) / secPerBar;
  const phrase32Progress = (safeTime % (secPerBar * 32)) / (secPerBar * 32);

  return {
    bar,
    beat,
    sixteenth,
    barProgress,
    phrase32Progress,
    totalSeconds: safeTime,
  };
}

/**
 * Computes playbackRate multiplier from touch-drag pitch bend offset (-100% to +100%).
 * Range typically +/- 8% or +/- 16% for DJ pitch bending.
 */
export function calculatePitchBendRate(dragOffsetPercent: number, maxRange = 0.16): number {
  const clamped = Math.max(-1, Math.min(1, dragOffsetPercent));
  return 1.0 + clamped * maxRange;
}

/**
 * Camelot wheel compatibility check.
 * Identifies if two harmonic keys can mix cleanly without dissonance.
 * e.g., '8A' compatible with '8A', '7A', '9A', and '8B'.
 */
export function isCamelotCompatible(keyA: string, keyB: string): boolean {
  const normA = keyA.trim().toUpperCase();
  const normB = keyB.trim().toUpperCase();

  if (normA === normB) return true;

  const matchA = normA.match(/^(\d{1,2})([AB])/);
  const matchB = normB.match(/^(\d{1,2})([AB])/);

  if (!matchA || !matchB) {
    // If not standard Camelot, accept if identical or both minor
    return normA === normB;
  }

  const numA = parseInt(matchA[1], 10);
  const letterA = matchA[2];
  const numB = parseInt(matchB[1], 10);
  const letterB = matchB[2];

  // Same key number, opposite mode (e.g. 8A <-> 8B)
  if (numA === numB && letterA !== letterB) return true;

  // Same mode, adjacent on 12-hour wheel (e.g. 8A <-> 7A or 9A, 12 <-> 1)
  if (letterA === letterB) {
    const diff = Math.abs(numA - numB);
    if (diff === 1 || diff === 11) return true;
  }

  return false;
}

/**
 * Calculates phase offset in radians [0, 2*PI] between two tracks given their beat positions.
 */
export function calculatePhaseOffset(timeA: number, timeB: number, bpm: number): number {
  const secPerBeat = bpmToSecondsPerBeat(bpm);
  const beatProgA = (timeA % secPerBeat) / secPerBeat;
  const beatProgB = (timeB % secPerBeat) / secPerBeat;
  const diff = (beatProgB - beatProgA + 1) % 1;
  return diff * 2 * Math.PI;
}
