/**
 * KlangStripe Hard Techno Web Audio DSP Engine
 * Ultra-optimized for mobile Web Audio API (iOS Safari / WebKit)
 * Features 3-stem dynamic isolation, linear touch stripe scrubbing, and industrial FX pipeline
 */

import {
  calculateBarPosition,
  calculatePitchBendRate,
  BarPosition,
} from './tempo-grid.ts';
import {
  calculateDJFilterState,
  makeDistortionCurve,
  calculateDelaySeconds,
} from './dsp-math.ts';

export interface StemLevels {
  drums: number; // 0.0 to 1.5
  acid: number;
  vocals: number;
}

export interface StemMutes {
  drums: boolean;
  acid: boolean;
  vocals: boolean;
}

export interface EngineState {
  isPlaying: boolean;
  bpm: number;
  pitchBend: number; // -1 to 1
  currentTime: number;
  duration: number;
  progress: number; // 0 to 1
  barPosition: BarPosition;
  filterFrequency: number;
  filterMode: 'flat' | 'lowpass' | 'highpass';
  distortionAmount: number;
  reverbFreeze: boolean;
  stemLevels: StemLevels;
  stemMutes: StemMutes;
  activeTrackId: string;
  vuLevels: {
    drums: number;
    acid: number;
    vocals: number;
    master: number;
  };
}

export interface TrackData {
  id: string;
  title: string;
  bpm: number;
  key: string;
  genre: string;
  barsTotal: number;
  isCustom?: boolean;
  buffer?: AudioBuffer;
  waveformPeaks?: number[];
}

export class HardTechnoEngine {
  private ctx: AudioContext | null = null;
  private isInitialized = false;
  private isPlaying = false;
  private bpm = 155;
  private pitchBendRate = 1.0;
  private currentPlaybackTime = 0;
  private duration = 124; // ~32 bars at 155 BPM
  private timerId: number | null = null;
  private nextNoteTime = 0;
  private current16thNote = 0;
  private listeners: Set<(state: EngineState) => void> = new Set();

  // Stem Gains
  private drumsGain: GainNode | null = null;
  private acidGain: GainNode | null = null;
  private vocalsGain: GainNode | null = null;
  private masterGain: GainNode | null = null;

  // Industrial FX Nodes
  private filterNode: BiquadFilterNode | null = null;
  private distortionNode: WaveShaperNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;
  private delayMixGain: GainNode | null = null;
  private reverbConvolver: ConvolverNode | null = null;
  private reverbGain: GainNode | null = null;
  private freezeGain: GainNode | null = null;
  private isReverbFrozen = false;

  // Custom Audio Buffer support (Swift loadTrack parity)
  private customBufferSource: AudioBufferSourceNode | null = null;
  private customAudioBuffer: AudioBuffer | null = null;
  private customBufferStartTime = 0;
  private customBufferOffset = 0;

  // State values
  private stemVolumes: StemLevels = { drums: 1.0, acid: 1.0, vocals: 0.9 };
  private stemMutes: StemMutes = { drums: false, acid: false, vocals: false };
  private filterSliderValue = 0.5; // Center flat
  private filterFrequency = 20000;
  private distortionDrive = 15; // +15% default drive
  private delayDivision: '1/2' | '1/4' | '1/8' | '1/8T' = '1/4';
  private activeTrackId = 'monolith';

  // VU Meters state
  private vuLevels = { drums: 0, acid: 0, vocals: 0, master: 0 };

  constructor() {
    // Engine starts uninitialized until first user gesture (iOS WebKit requirement)
  }

  public async initAudio(): Promise<boolean> {
    if (this.isInitialized && this.ctx && this.ctx.state === 'running') {
      return true;
    }

    try {
      const AudioCtxClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      
      this.ctx = new AudioCtxClass({
        latencyHint: 'interactive',
      });

      if (this.ctx.state === 'suspended') {
        await this.ctx.resume();
      }

      this.setupAudioGraph();
      this.isInitialized = true;
      this.notifyListeners();
      return true;
    } catch (err) {
      console.error('Failed to initialize AudioContext:', err);
      return false;
    }
  }

  private setupAudioGraph() {
    if (!this.ctx) return;

    // Master Output Chain:
    // Stem Gains -> FX Chain (Filter -> Distortion -> Delay & Reverb) -> Master Gain -> Destination
    this.drumsGain = this.ctx.createGain();
    this.acidGain = this.ctx.createGain();
    this.vocalsGain = this.ctx.createGain();

    // Master sum bus
    const stemBus = this.ctx.createGain();
    this.drumsGain.connect(stemBus);
    this.acidGain.connect(stemBus);
    this.vocalsGain.connect(stemBus);

    // Superpowered-style Bi-directional DJ Filter
    this.filterNode = this.ctx.createBiquadFilter();
    this.filterNode.type = 'allpass';
    this.filterNode.frequency.setValueAtTime(20000, this.ctx.currentTime);
    this.filterNode.Q.setValueAtTime(1.5, this.ctx.currentTime);

    // Overdrive / Distortion
    this.distortionNode = this.ctx.createWaveShaper();
    this.distortionNode.curve = makeDistortionCurve(this.distortionDrive) as Float32Array<ArrayBuffer>;
    this.distortionNode.oversample = '4x';

    // Delay with feedback
    this.delayNode = this.ctx.createDelay(2.0);
    this.delayNode.delayTime.setValueAtTime(
      calculateDelaySeconds(this.bpm, this.delayDivision),
      this.ctx.currentTime
    );
    this.delayFeedback = this.ctx.createGain();
    this.delayFeedback.gain.setValueAtTime(0.35, this.ctx.currentTime);
    this.delayMixGain = this.ctx.createGain();
    this.delayMixGain.gain.setValueAtTime(0.2, this.ctx.currentTime);

    this.delayNode.connect(this.delayFeedback);
    this.delayFeedback.connect(this.delayNode);
    this.delayNode.connect(this.delayMixGain);

    // Reverb & Freeze system
    this.reverbConvolver = this.ctx.createConvolver();
    this.reverbConvolver.buffer = this.createSyntheticReverbImpulse(1.8, 2.5);
    this.reverbGain = this.ctx.createGain();
    this.reverbGain.gain.setValueAtTime(0.25, this.ctx.currentTime);
    this.freezeGain = this.ctx.createGain();
    this.freezeGain.gain.setValueAtTime(0.0, this.ctx.currentTime);

    // Master Output
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(0.9, this.ctx.currentTime);

    // Audio Graph Wiring:
    // stemBus -> filterNode -> distortionNode
    stemBus.connect(this.filterNode);
    this.filterNode.connect(this.distortionNode);

    // Dry path to master
    this.distortionNode.connect(this.masterGain);

    // Send to Delay
    this.distortionNode.connect(this.delayNode);
    this.delayMixGain.connect(this.masterGain);

    // Send to Reverb
    this.distortionNode.connect(this.reverbConvolver);
    this.reverbConvolver.connect(this.reverbGain);
    this.reverbGain.connect(this.masterGain);

    // Connect master to audio hardware
    this.masterGain.connect(this.ctx.destination);

    this.updateStemGains();
  }

  /**
   * Generates a rich, industrial synthetic reverb impulse for warehouse/concrete space
   */
  private createSyntheticReverbImpulse(durationSec: number, decay: number): AudioBuffer {
    if (!this.ctx) {
      throw new Error('AudioContext missing');
    }
    const sampleRate = this.ctx.sampleRate;
    const length = sampleRate * durationSec;
    const impulse = this.ctx.createBuffer(2, length, sampleRate);
    const left = impulse.getChannelData(0);
    const right = impulse.getChannelData(1);

    for (let i = 0; i < length; i++) {
      const n = i / length;
      const factor = Math.exp(-n * decay);
      left[i] = (Math.random() * 2 - 1) * factor;
      right[i] = (Math.random() * 2 - 1) * factor;
    }
    return impulse;
  }

  public subscribe(cb: (state: EngineState) => void): () => void {
    this.listeners.add(cb);
    cb(this.getState());
    return () => {
      this.listeners.delete(cb);
    };
  }

  private notifyListeners() {
    const state = this.getState();
    this.listeners.forEach((cb) => cb(state));
  }

  public getState(): EngineState {
    const barPos = calculateBarPosition(this.currentPlaybackTime, this.bpm);
    const filterState = calculateDJFilterState(this.filterSliderValue);

    return {
      isPlaying: this.isPlaying,
      bpm: this.bpm,
      pitchBend: this.pitchBendRate - 1.0,
      currentTime: this.currentPlaybackTime,
      duration: this.duration,
      progress: this.duration > 0 ? this.currentPlaybackTime / this.duration : 0,
      barPosition: barPos,
      filterFrequency: filterState.frequency,
      filterMode: filterState.mode,
      distortionAmount: this.distortionDrive,
      reverbFreeze: this.isReverbFrozen,
      stemLevels: { ...this.stemVolumes },
      stemMutes: { ...this.stemMutes },
      activeTrackId: this.activeTrackId,
      vuLevels: { ...this.vuLevels },
    };
  }

  // MARK: - Playback Controls
  public async play(): Promise<void> {
    await this.initAudio();
    if (!this.ctx) return;

    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }

    if (this.isPlaying) return;

    this.isPlaying = true;

    if (this.customAudioBuffer) {
      this.startCustomBufferPlayback();
    } else {
      this.nextNoteTime = this.ctx.currentTime;
      this.startSynthesizerLoop();
    }

    this.notifyListeners();
  }

  public pause(): void {
    this.isPlaying = false;
    if (this.timerId !== null) {
      window.cancelAnimationFrame(this.timerId);
      this.timerId = null;
    }
    if (this.customBufferSource) {
      try {
        this.customBufferSource.stop();
      } catch {
        // already stopped
      }
      this.customBufferSource = null;
    }
    this.notifyListeners();
  }

  public togglePlay(): void {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  // MARK: - Waveform Touch Stripe Navigation
  /**
   * Instantly needle drop / jump to exact percentage (0.0 to 1.0) along touch stripe
   */
  public needleDrop(progressPercent: number): void {
    const clamped = Math.max(0, Math.min(1, progressPercent));
    this.currentPlaybackTime = clamped * this.duration;

    // Recalculate 16th note index to match bar grid
    const secPer16th = (60 / this.bpm) / 4;
    this.current16thNote = Math.floor(this.currentPlaybackTime / secPer16th);

    if (this.customAudioBuffer && this.isPlaying) {
      this.pause();
      this.play();
    }

    this.notifyListeners();
  }

  /**
   * Scrubbing gesture handler
   */
  public scrubTo(progressPercent: number): void {
    this.needleDrop(progressPercent);
    // Trigger momentary scrub transient if initialized
    if (this.ctx && this.isPlaying) {
      this.triggerScrubChirp();
    }
  }

  private triggerScrubChirp() {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(180, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(60, this.ctx.currentTime + 0.05);

    gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    osc.connect(gain);
    if (this.filterNode) gain.connect(this.filterNode);
    osc.start();
    osc.stop(this.ctx.currentTime + 0.06);
  }

  /**
   * Dynamic Touch-Drag Pitch Bending / Nudge
   * @param offset -1.0 to 1.0
   */
  public setPitchBend(offset: number): void {
    this.pitchBendRate = calculatePitchBendRate(offset, 0.16);
    if (this.customBufferSource && this.ctx) {
      this.customBufferSource.playbackRate.setValueAtTime(
        this.pitchBendRate,
        this.ctx.currentTime
      );
    }
    this.notifyListeners();
  }

  public releasePitchBend(): void {
    this.pitchBendRate = 1.0;
    if (this.customBufferSource && this.ctx) {
      this.customBufferSource.playbackRate.setValueAtTime(
        1.0,
        this.ctx.currentTime
      );
    }
    this.notifyListeners();
  }

  // MARK: - 3-Stem Dynamic Control
  public setStemLevel(stem: keyof StemLevels, level: number): void {
    this.stemVolumes[stem] = Math.max(0, Math.min(1.5, level));
    this.updateStemGains();
    this.notifyListeners();
  }

  public toggleStemMute(stem: keyof StemMutes): void {
    this.stemMutes[stem] = !this.stemMutes[stem];
    this.updateStemGains();
    this.notifyListeners();
  }

  public soloStem(stem: keyof StemMutes): void {
    const isCurrentlySolo =
      !this.stemMutes[stem] &&
      Object.entries(this.stemMutes).every(
        ([k, v]) => k === stem || v === true
      );

    if (isCurrentlySolo) {
      // Un-solo: unmute all
      this.stemMutes = { drums: false, acid: false, vocals: false };
    } else {
      // Solo selected stem
      this.stemMutes = {
        drums: stem !== 'drums',
        acid: stem !== 'acid',
        vocals: stem !== 'vocals',
      };
    }
    this.updateStemGains();
    this.notifyListeners();
  }

  private updateStemGains() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;

    if (this.drumsGain) {
      const vol = this.stemMutes.drums ? 0 : this.stemVolumes.drums;
      this.drumsGain.gain.setTargetAtTime(vol, t, 0.02);
    }
    if (this.acidGain) {
      const vol = this.stemMutes.acid ? 0 : this.stemVolumes.acid;
      this.acidGain.gain.setTargetAtTime(vol, t, 0.02);
    }
    if (this.vocalsGain) {
      const vol = this.stemMutes.vocals ? 0 : this.stemVolumes.vocals;
      this.vocalsGain.gain.setTargetAtTime(vol, t, 0.02);
    }
  }

  // MARK: - Industrial Audio FX Controls
  /**
   * Sets DJ Filter (0.0 to 1.0, 0.5 is center flat, like Superpowered filter)
   */
  public setFilterSlider(val: number): void {
    this.filterSliderValue = Math.max(0, Math.min(1, val));
    const filterState = calculateDJFilterState(this.filterSliderValue);
    this.filterFrequency = filterState.frequency;

    if (this.filterNode && this.ctx) {
      const t = this.ctx.currentTime;
      if (filterState.mode === 'flat') {
        this.filterNode.type = 'allpass';
        this.filterNode.frequency.setTargetAtTime(20000, t, 0.02);
      } else if (filterState.mode === 'lowpass') {
        this.filterNode.type = 'lowpass';
        this.filterNode.frequency.setTargetAtTime(filterState.frequency, t, 0.02);
        this.filterNode.Q.setTargetAtTime(filterState.resonanceQ, t, 0.02);
      } else if (filterState.mode === 'highpass') {
        this.filterNode.type = 'highpass';
        this.filterNode.frequency.setTargetAtTime(filterState.frequency, t, 0.02);
        this.filterNode.Q.setTargetAtTime(filterState.resonanceQ, t, 0.02);
      }
    }
    this.notifyListeners();
  }

  /**
   * Superpowered slider frequency in Hz directly (Swift parity)
   */
  public setFilterFrequencyHz(freqHz: number): void {
    const clampedHz = Math.max(20, Math.min(20000, freqHz));
    this.filterFrequency = clampedHz;
    if (this.filterNode && this.ctx) {
      this.filterNode.type = 'lowpass';
      this.filterNode.frequency.setTargetAtTime(clampedHz, this.ctx.currentTime, 0.02);
    }
    this.notifyListeners();
  }

  public setDistortionDrive(drive: number): void {
    this.distortionDrive = Math.max(0, Math.min(100, drive));
    if (this.distortionNode) {
      this.distortionNode.curve = makeDistortionCurve(this.distortionDrive) as Float32Array<ArrayBuffer>;
    }
    this.notifyListeners();
  }

  public setDelayDivision(div: '1/2' | '1/4' | '1/8' | '1/8T'): void {
    this.delayDivision = div;
    if (this.delayNode && this.ctx) {
      const sec = calculateDelaySeconds(this.bpm, div);
      this.delayNode.delayTime.setTargetAtTime(sec, this.ctx.currentTime, 0.05);
    }
    this.notifyListeners();
  }

  public toggleReverbFreeze(): void {
    this.isReverbFrozen = !this.isReverbFrozen;
    if (this.reverbGain && this.ctx) {
      const t = this.ctx.currentTime;
      // When frozen, boost reverb tail wetness to 90% and hold
      this.reverbGain.gain.setTargetAtTime(this.isReverbFrozen ? 0.9 : 0.25, t, 0.05);
    }
    this.notifyListeners();
  }

  public setBpm(newBpm: number): void {
    this.bpm = Math.max(130, Math.min(180, newBpm));
    if (this.delayNode && this.ctx) {
      const sec = calculateDelaySeconds(this.bpm, this.delayDivision);
      this.delayNode.delayTime.setValueAtTime(sec, this.ctx.currentTime);
    }
    this.notifyListeners();
  }

  // MARK: - Track Management & Custom Track Upload (Swift parity)
  public async loadCustomAudioFile(file: File): Promise<TrackData> {
    await this.initAudio();
    if (!this.ctx) throw new Error('AudioContext missing');

    const arrayBuffer = await file.arrayBuffer();
    const audioBuffer = await this.ctx.decodeAudioData(arrayBuffer);

    this.customAudioBuffer = audioBuffer;
    this.duration = audioBuffer.duration;
    this.currentPlaybackTime = 0;
    this.activeTrackId = 'custom';

    // Extract real waveform sample peaks (matching FDWaveformView)
    const rawData = audioBuffer.getChannelData(0);
    const sampleCount = 200;
    const blockSize = Math.floor(rawData.length / sampleCount);
    const peaks: number[] = [];

    for (let i = 0; i < sampleCount; i++) {
      let sum = 0;
      for (let j = 0; j < blockSize; j++) {
        sum += Math.abs(rawData[i * blockSize + j]);
      }
      peaks.push(Math.min(1.0, (sum / blockSize) * 2.2));
    }

    const trackData: TrackData = {
      id: 'custom',
      title: file.name.replace(/\.[^/.]+$/, ''),
      bpm: 155,
      key: '8A (Am)',
      genre: 'Industrial Underground',
      barsTotal: Math.floor(audioBuffer.duration / (60 / 155 * 4)),
      isCustom: true,
      buffer: audioBuffer,
      waveformPeaks: peaks,
    };

    this.notifyListeners();
    return trackData;
  }

  public selectTrack(trackId: string): void {
    this.activeTrackId = trackId;
    this.customAudioBuffer = null;
    this.currentPlaybackTime = 0;
    this.duration = 124; // standard 32-bar loop at 155 BPM
    if (trackId === 'acid_hex') {
      this.bpm = 158;
    } else if (trackId === 'concrete_vault') {
      this.bpm = 162;
    } else {
      this.bpm = 155;
    }
    this.notifyListeners();
  }

  // MARK: - Web Audio Hard Techno Synthesizer Engine
  private startSynthesizerLoop() {
    const loop = () => {
      if (!this.isPlaying || !this.ctx) return;

      const scheduleAheadTime = 0.1;
      const secPer16th = (60 / (this.bpm * this.pitchBendRate)) / 4;

      while (this.nextNoteTime < this.ctx.currentTime + scheduleAheadTime) {
        this.schedule16thNote(this.current16thNote, this.nextNoteTime);
        this.nextNoteTime += secPer16th;
        this.currentPlaybackTime += secPer16th;
        if (this.currentPlaybackTime >= this.duration) {
          this.currentPlaybackTime = 0;
        }
        this.current16thNote = (this.current16thNote + 1) % (32 * 16);
      }

      // Decay VU meters
      this.vuLevels.drums = Math.max(0, this.vuLevels.drums - 0.08);
      this.vuLevels.acid = Math.max(0, this.vuLevels.acid - 0.08);
      this.vuLevels.vocals = Math.max(0, this.vuLevels.vocals - 0.08);
      this.vuLevels.master = Math.max(
        0,
        (this.vuLevels.drums + this.vuLevels.acid + this.vuLevels.vocals) / 2.5
      );

      this.notifyListeners();
      this.timerId = window.requestAnimationFrame(loop);
    };

    this.timerId = window.requestAnimationFrame(loop);
  }

  private schedule16thNote(step: number, time: number) {
    if (!this.ctx) return;

    const beatInBar = Math.floor((step % 16) / 4); // 0 to 3
    const stepInBeat = step % 4; // 0 to 3 (0 = downbeat)
    const bar32 = Math.floor(step / 16);

    // 1. STEM 1: DRUMS & RUMBLE
    // 909 Kick on every quarter note (stepInBeat === 0)
    if (stepInBeat === 0 && !this.stemMutes.drums) {
      this.triggerKick(time);
      this.triggerSubRumble(time);
      this.vuLevels.drums = 0.95;
    }

    // 909 Offbeat Closed Hi-Hats on step 2 of every beat (stepInBeat === 2)
    if (stepInBeat === 2 && !this.stemMutes.drums) {
      this.triggerHat(time, 0.45);
    } else if (stepInBeat === 1 || stepInBeat === 3) {
      // 16th rolling ghost hats
      if (bar32 % 2 === 1 && !this.stemMutes.drums) {
        this.triggerHat(time, 0.18);
      }
    }

    // Industrial Clap on Beat 2 and 4 (beatInBar === 1 or 3, stepInBeat === 0)
    if ((beatInBar === 1 || beatInBar === 3) && stepInBeat === 0 && !this.stemMutes.drums) {
      this.triggerClap(time);
    }

    // 2. STEM 2: ACID & HARMONICS (Roland TB-303 Sequence)
    if (!this.stemMutes.acid) {
      // 16-step classic Hard Acid sequence notes in A Minor / Phrygian
      // [A1, A1, C2, A1, D2, C2, G1, A1, Eb2, D2, C2, A1, F2, E2, C2, G1]
      const acidNotes = [55, 55, 65.4, 55, 73.4, 65.4, 49.0, 55, 77.8, 73.4, 65.4, 55, 87.3, 82.4, 65.4, 49.0];
      const noteFreq = acidNotes[step % acidNotes.length];
      const isAccent = (step % 4 === 0) || (step % 7 === 0);

      // Play note on active steps
      if (step % 2 === 0 || isAccent) {
        this.triggerAcidNote(time, noteFreq, isAccent);
        this.vuLevels.acid = Math.max(this.vuLevels.acid, isAccent ? 0.9 : 0.6);
      }
    }

    // 3. STEM 3: VOCALS & INDUSTRIAL FX
    if (!this.stemMutes.vocals) {
      // Periodic vocal chop or industrial metallic burst every 8 bars
      if (step % 64 === 0) {
        this.triggerIndustrialNoiseBurst(time);
        this.vuLevels.vocals = 0.85;
      } else if (step % 32 === 28) {
        this.triggerReverseCymbalSwell(time);
        this.vuLevels.vocals = 0.7;
      }
    }
  }

  // MARK: - DSP Voice Synthesis
  private triggerKick(time: number) {
    if (!this.ctx || !this.drumsGain) return;

    // Pitch envelope: 155Hz transient drop down to 42Hz punch
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(155, time);
    osc.frequency.exponentialRampToValueAtTime(42, time + 0.08);

    gain.gain.setValueAtTime(1.0, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.28);

    osc.connect(gain);
    gain.connect(this.drumsGain);

    osc.start(time);
    osc.stop(time + 0.3);
  }

  private triggerSubRumble(time: number) {
    if (!this.ctx || !this.drumsGain) return;

    // Sub rumble: 40Hz with sidechain ducking curve
    const subOsc = this.ctx.createOscillator();
    const subGain = this.ctx.createGain();
    const subFilter = this.ctx.createBiquadFilter();

    subOsc.type = 'triangle';
    subOsc.frequency.setValueAtTime(38, time);

    subFilter.type = 'lowpass';
    subFilter.frequency.setValueAtTime(90, time);

    // Sidechain compression curve: duck on kick hit, swell on 16th note 2
    subGain.gain.setValueAtTime(0.05, time); // ducked by kick
    subGain.gain.linearRampToValueAtTime(0.55, time + 0.14); // rumble swell
    subGain.gain.exponentialRampToValueAtTime(0.01, time + 0.38);

    subOsc.connect(subFilter);
    subFilter.connect(subGain);
    subGain.connect(this.drumsGain);

    subOsc.start(time);
    subOsc.stop(time + 0.4);
  }

  private triggerHat(time: number, velocity = 0.35) {
    if (!this.ctx || !this.drumsGain) return;

    // Highpass noise for metallic closed 909 hat
    const bufferSize = this.ctx.sampleRate * 0.05;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noiseSource = this.ctx.createBufferSource();
    noiseSource.buffer = noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(7500, time);
    filter.Q.setValueAtTime(3.0, time);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(velocity, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.05);

    noiseSource.connect(filter);
    filter.connect(gain);
    gain.connect(this.drumsGain);

    noiseSource.start(time);
    noiseSource.stop(time + 0.06);
  }

  private triggerClap(time: number) {
    if (!this.ctx || !this.drumsGain) return;

    // Multi-pulse 909 style clap
    const pulses = [0, 0.01, 0.02, 0.035];
    pulses.forEach((pulseOffset) => {
      if (!this.ctx || !this.drumsGain) return;
      const noise = this.createNoiseBurst(0.06);
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1200, time + pulseOffset);
      filter.Q.setValueAtTime(1.5, time + pulseOffset);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(pulseOffset === 0.035 ? 0.45 : 0.2, time + pulseOffset);
      gain.gain.exponentialRampToValueAtTime(0.001, time + pulseOffset + 0.08);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.drumsGain);
      noise.start(time + pulseOffset);
      noise.stop(time + pulseOffset + 0.09);
    });
  }

  private triggerAcidNote(time: number, freq: number, isAccent: boolean) {
    if (!this.ctx || !this.acidGain) return;

    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = isAccent ? 'sawtooth' : 'square';
    osc.frequency.setValueAtTime(freq, time);

    // Screaming 303 resonant 24dB-style filter sweep
    filter.type = 'lowpass';
    filter.Q.setValueAtTime(isAccent ? 14.0 : 8.0, time);

    const baseCutoff = isAccent ? 450 : 250;
    const peakCutoff = isAccent ? 3800 : 1800;
    const decayTime = isAccent ? 0.22 : 0.14;

    filter.frequency.setValueAtTime(baseCutoff, time);
    filter.frequency.exponentialRampToValueAtTime(peakCutoff, time + 0.02);
    filter.frequency.exponentialRampToValueAtTime(baseCutoff, time + decayTime);

    gain.gain.setValueAtTime(isAccent ? 0.5 : 0.35, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + decayTime + 0.02);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.acidGain);

    osc.start(time);
    osc.stop(time + decayTime + 0.05);
  }

  private triggerIndustrialNoiseBurst(time: number) {
    if (!this.ctx || !this.vocalsGain) return;

    const noise = this.createNoiseBurst(0.3);
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(2400, time);
    filter.frequency.exponentialRampToValueAtTime(600, time + 0.28);
    filter.Q.setValueAtTime(4.0, time);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.4, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.3);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.vocalsGain);

    noise.start(time);
    noise.stop(time + 0.32);
  }

  private triggerReverseCymbalSwell(time: number) {
    if (!this.ctx || !this.vocalsGain) return;

    const noise = this.createNoiseBurst(0.4);
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(4000, time);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.01, time);
    gain.gain.exponentialRampToValueAtTime(0.4, time + 0.35);
    gain.gain.setValueAtTime(0.001, time + 0.38);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.vocalsGain);

    noise.start(time);
    noise.stop(time + 0.4);
  }

  private createNoiseBurst(durationSec: number): AudioBufferSourceNode {
    if (!this.ctx) throw new Error('AudioContext missing');
    const length = Math.floor(this.ctx.sampleRate * durationSec);
    const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
    const channel = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      channel[i] = Math.random() * 2 - 1;
    }
    const source = this.ctx.createBufferSource();
    source.buffer = buffer;
    return source;
  }

  // MARK: - Custom Audio Playback (Swift loadTrack parity)
  private startCustomBufferPlayback() {
    if (!this.ctx || !this.customAudioBuffer || !this.drumsGain) return;

    if (this.customBufferSource) {
      try {
        this.customBufferSource.stop();
      } catch {
        // already stopped
      }
    }

    this.customBufferSource = this.ctx.createBufferSource();
    this.customBufferSource.buffer = this.customAudioBuffer;
    this.customBufferSource.playbackRate.setValueAtTime(
      this.pitchBendRate,
      this.ctx.currentTime
    );

    // Route to drums/master
    this.customBufferSource.connect(this.drumsGain);

    this.customBufferStartTime = this.ctx.currentTime - this.currentPlaybackTime;
    this.customBufferSource.start(0, this.currentPlaybackTime);

    // Poll position
    const pollLoop = () => {
      if (!this.isPlaying || !this.ctx) return;
      this.currentPlaybackTime =
        (this.ctx.currentTime - this.customBufferStartTime) % this.duration;

      this.vuLevels.drums = 0.7;
      this.vuLevels.master = 0.75;
      this.notifyListeners();

      this.timerId = window.requestAnimationFrame(pollLoop);
    };
    this.timerId = window.requestAnimationFrame(pollLoop);
  }
}

// Global engine singleton
export const audioEngine = new HardTechnoEngine();
