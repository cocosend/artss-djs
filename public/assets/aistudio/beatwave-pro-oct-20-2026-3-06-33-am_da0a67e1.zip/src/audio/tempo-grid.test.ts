import test from 'node:test';
import assert from 'node:assert/strict';
import {
  bpmToSecondsPerBeat,
  bpmToSecondsPerBar,
  calculateBarPosition,
  calculatePitchBendRate,
  isCamelotCompatible,
  calculatePhaseOffset,
} from './tempo-grid.ts';

test('bpmToSecondsPerBeat calculates correct beat length for Hard Techno tempos', () => {
  // At 150 BPM, 60 / 150 = 0.4 seconds per beat
  assert.equal(bpmToSecondsPerBeat(150), 0.4);
  // At 160 BPM, 60 / 160 = 0.375 seconds per beat
  assert.equal(bpmToSecondsPerBeat(160), 0.375);
  // At 120 BPM, 60 / 120 = 0.5 seconds
  assert.equal(bpmToSecondsPerBeat(120), 0.5);
});

test('bpmToSecondsPerBar calculates 4-beat bar length', () => {
  // At 150 BPM, bar is 4 * 0.4 = 1.6s
  assert.equal(bpmToSecondsPerBar(150), 1.6);
  // At 160 BPM, bar is 4 * 0.375 = 1.5s
  assert.equal(bpmToSecondsPerBar(160), 1.5);
});

test('calculateBarPosition returns correct Bar, Beat, and 16th count', () => {
  const bpm = 150; // 1.6s per bar, 0.4s per beat, 0.1s per 16th
  
  // Exact start
  const posStart = calculateBarPosition(0, bpm);
  assert.equal(posStart.bar, 1);
  assert.equal(posStart.beat, 1);
  assert.equal(posStart.sixteenth, 1);

  // At 0.45s: 1st bar, 2nd beat (0.4s to 0.8s), 1st 16th (0.40 to 0.50s)
  const pos2 = calculateBarPosition(0.45, bpm);
  assert.equal(pos2.bar, 1);
  assert.equal(pos2.beat, 2);
  assert.equal(pos2.sixteenth, 1);

  // At 3.2s: exactly 2 full bars finished -> Start of Bar 3
  const pos3 = calculateBarPosition(3.2, bpm);
  assert.equal(pos3.bar, 3);
  assert.equal(pos3.beat, 1);
});

test('calculatePitchBendRate stays within maximum nudge boundary', () => {
  // 0 offset -> 1.0x rate
  assert.equal(calculatePitchBendRate(0), 1.0);
  // +50% drag at maxRange 0.16 -> 1.08x
  assert.equal(calculatePitchBendRate(0.5, 0.16), 1.08);
  // -100% drag at maxRange 0.16 -> 0.84x
  assert.equal(calculatePitchBendRate(-1.0, 0.16), 0.84);
  // Clamped at max 1.0
  assert.equal(calculatePitchBendRate(2.0, 0.16), 1.16);
});

test('isCamelotCompatible handles harmonic mixing matches', () => {
  // Identical keys
  assert.equal(isCamelotCompatible('8A', '8A'), true);
  // Adjacent on Camelot wheel
  assert.equal(isCamelotCompatible('8A', '9A'), true);
  assert.equal(isCamelotCompatible('8A', '7A'), true);
  // Wrap-around 12A <-> 1A
  assert.equal(isCamelotCompatible('12A', '1A'), true);
  // Relative major/minor switch
  assert.equal(isCamelotCompatible('8A', '8B'), true);

  // Incompatible clash (e.g. 8A and 2A)
  assert.equal(isCamelotCompatible('8A', '2A'), false);
});

test('calculatePhaseOffset computes circular beat phase', () => {
  const bpm = 150; // 0.4s beat
  // Both at start of beat -> 0 phase
  assert.equal(calculatePhaseOffset(0, 0, bpm), 0);
  // Half beat difference -> PI phase (180 deg)
  const halfBeatPhase = calculatePhaseOffset(0, 0.2, bpm);
  assert.ok(Math.abs(halfBeatPhase - Math.PI) < 0.001);
});
