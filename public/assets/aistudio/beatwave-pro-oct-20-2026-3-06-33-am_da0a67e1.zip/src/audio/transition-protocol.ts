/**
 * AI Hard Techno MasterMind - Transition Protocol Generator & Parser
 * Complies strictly with the system instruction output template.
 */

export interface TrackMetadata {
  title: string;
  bpm: number;
  key: string;
  drumRumbleDesc?: string;
  acidHarmonicsDesc?: string;
  vocalsFxDesc?: string;
}

export interface TransitionPlan {
  activeTrack: TrackMetadata;
  targetTrack: TrackMetadata;
  dropCuePercent: number;
  breakCuePercent: number;
  outroCuePercent: number;
  durationBars: number;
  timelineSteps: Array<{
    barRange: string;
    action: string;
    startBar: number;
    endBar: number;
  }>;
  filterDriveStrategy: string;
  spatialStrategy: string;
}

export function buildHardTechnoProtocolText(plan: TransitionPlan): string {
  const {
    activeTrack,
    targetTrack,
    dropCuePercent,
    breakCuePercent,
    outroCuePercent,
    durationBars,
    timelineSteps,
    filterDriveStrategy,
    spatialStrategy,
  } = plan;

  return `⚡ HARD TECHNO STEM & STRIPE ANALYSIS
Active Track: ${activeTrack.title} — BPM: ${activeTrack.bpm} | Key: ${activeTrack.key}
Target Track: ${targetTrack.title} — BPM: ${targetTrack.bpm} | Key: ${targetTrack.key}
Touch Stripe Cue Points: Drop Cue ${dropCuePercent.toFixed(1)}%, Break Cue ${breakCuePercent.toFixed(1)}%, Outro Cue ${outroCuePercent.toFixed(1)}%
Stem Profile:
Drums/Rumble: ${activeTrack.drumRumbleDesc || 'Relentless 909 sub-rumble, heavy saturation at 45Hz'}
Acid/Harmonics: ${activeTrack.acidHarmonicsDesc || 'Resonant 303 square bassline with swept cutoff'}
Vocals/FX: ${activeTrack.vocalsFxDesc || 'Distorted industrial voice cuts and white noise riser'}

🎛️ WAVEFORM TOUCH STRIPE TRANSITION PROTOCOL
Transition Duration: ${durationBars} Bars / Touch-stripe Scrub to Bar ${Math.floor(durationBars / 2)} Drop
Step-by-Step Timeline:
${timelineSteps
  .map(
    (step, idx) =>
      `${idx + 1}. [${step.barRange}]: ${step.action}`
  )
  .join('\n')}

💥 HARD FX & DRIVE EXECUTION
Filter & Drive: ${filterDriveStrategy}
Spatial Modulation: ${spatialStrategy}`;
}

export function generateStandard32BarPlan(
  activeTrack: TrackMetadata,
  targetTrack: TrackMetadata,
  durationBars: number = 32
): TransitionPlan {
  const midBar = Math.floor(durationBars / 2);
  const q1Bar = Math.floor(durationBars / 4);

  return {
    activeTrack,
    targetTrack,
    dropCuePercent: 50.0,
    breakCuePercent: 25.0,
    outroCuePercent: 87.5,
    durationBars,
    timelineSteps: [
      {
        startBar: 1,
        endBar: q1Bar,
        barRange: `Bar 1–${q1Bar}`,
        action: `Drag Touch Stripe to Target Intro Marker; engage 18dB/oct resonant HPF sweep on Active Drums/Rumble to carve sub headroom.`,
      },
      {
        startBar: q1Bar + 1,
        endBar: midBar,
        barRange: `Bar ${q1Bar + 1}–${midBar}`,
        action: `Pitch-bend Target via Touch Stripe to lock phase; cross-fade Acid/Harmonics stem on Bar ${midBar} beat 4.`,
      },
      {
        startBar: midBar + 1,
        endBar: durationBars,
        barRange: `Bar ${midBar + 1}–${durationBars}`,
        action: `Hard mute Active Drums; slam Target Drums/Rumble via instant touch drop; engage Bitcrush saturation on outro tails.`,
      },
    ],
    filterDriveStrategy: `Engage Resonant HPF sweep from 200Hz to 3.5kHz with +16% tube overdrive on Acid Stem.`,
    spatialStrategy: `1/4 Feedback Delay + Reverb Freeze tail kill at Bar ${durationBars}, Drop into raw Kick Rumble at 0.0s.`,
  };
}
