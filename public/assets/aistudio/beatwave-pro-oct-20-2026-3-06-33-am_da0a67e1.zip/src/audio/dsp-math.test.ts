import test from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizedToLogHz,
  hzToNormalizedLog,
  calculateDJFilterState,
  makeDistortionCurve,
  quantizeBitDepth,
  calculateDelaySeconds,
} from './dsp-math.ts';

test('normalizedToLogHz maps 0 to minHz and 1 to maxHz logarithmically', () => {
  const minHz = 20;
  const maxHz = 20000;
  assert.equal(normalizedToLogHz(0, minHz, maxHz), 20);
  assert.equal(normalizedToLogHz(1, minHz, maxHz), 20000);

  // Geometric center (0.5) is sqrt(20 * 20000) = sqrt(400,000) approx 632 Hz
  const centerHz = normalizedToLogHz(0.5, minHz, maxHz);
  assert.ok(centerHz >= 620 && centerHz <= 645);
});

test('hzToNormalizedLog is the exact inverse of normalizedToLogHz', () => {
  const testPoints = [0.1, 0.25, 0.5, 0.75, 0.9];
  for (const p of testPoints) {
    const hz = normalizedToLogHz(p, 20, 20000);
    const roundTrip = hzToNormalizedLog(hz, 20, 20000);
    assert.ok(Math.abs(p - roundTrip) < 0.01, `Failed for ${p}: got ${roundTrip}`);
  }
});

test('calculateDJFilterState produces flat at center, lowpass on left, highpass on right', () => {
  // Center: neutral flat
  const centerState = calculateDJFilterState(0.5);
  assert.equal(centerState.mode, 'flat');

  // Left: LowPass
  const lowPassState = calculateDJFilterState(0.2);
  assert.equal(lowPassState.mode, 'lowpass');
  assert.ok(lowPassState.frequency < 10000);

  // Right: HighPass
  const highPassState = calculateDJFilterState(0.8);
  assert.equal(highPassState.mode, 'highpass');
  assert.ok(highPassState.frequency > 500);
});

test('makeDistortionCurve returns symmetric non-zero array', () => {
  const cleanCurve = makeDistortionCurve(0, 1024);
  assert.equal(cleanCurve.length, 1024);
  // At center (zero input) -> output zero
  assert.ok(Math.abs(cleanCurve[512]) < 0.01);

  const heavyDistortion = makeDistortionCurve(50, 1024);
  assert.equal(heavyDistortion.length, 1024);
  // High input should saturate near +/- 1.0
  assert.ok(heavyDistortion[1023] > 0.8);
  assert.ok(heavyDistortion[0] < -0.8);
});

test('quantizeBitDepth reduces steps for lower bit depths', () => {
  // 1-bit audio (2 steps)
  assert.equal(quantizeBitDepth(0.3, 1), 0.5); // steps = 2
  // 16-bit returns original
  assert.equal(quantizeBitDepth(0.333, 16), 0.333);
});

test('calculateDelaySeconds calculates tempo-synced subdivisions at 150 BPM', () => {
  const bpm = 150; // 0.4s per beat (1/4 note)
  assert.equal(calculateDelaySeconds(bpm, '1/4'), 0.4);
  assert.equal(calculateDelaySeconds(bpm, '1/2'), 0.8);
  assert.equal(calculateDelaySeconds(bpm, '1/8'), 0.2);
  // Triplet 1/8 note = 0.2 * (2/3) = 0.1333s
  const triplet = calculateDelaySeconds(bpm, '1/8T');
  assert.ok(Math.abs(triplet - 0.1333) < 0.001);
});
