/**
 * Industrial Audio FX & DSP Mathematics
 * Pure functions decoupled for unit testing and Web Audio API node setup
 */

export type DJFilterMode = 'flat' | 'lowpass' | 'highpass';

export interface DJFilterState {
  mode: DJFilterMode;
  frequency: number; // in Hz [20, 20000]
  resonanceQ: number; // typical Q value 0.7 to 8.0
}

/**
 * Maps normalized linear slider [0.0, 1.0] to audible frequency [minHz, maxHz] logarithmically.
 */
export function normalizedToLogHz(normalized: number, minHz = 20, maxHz = 20000): number {
  const clamped = Math.max(0, Math.min(1, normalized));
  return Math.round(minHz * Math.pow(maxHz / minHz, clamped));
}

/**
 * Maps frequency in Hz [minHz, maxHz] back to normalized linear value [0.0, 1.0].
 */
export function hzToNormalizedLog(hz: number, minHz = 20, maxHz = 20000): number {
  const clampedHz = Math.max(minHz, Math.min(maxHz, hz));
  return Math.log(clampedHz / minHz) / Math.log(maxHz / minHz);
}

/**
 * Standard DJ Bi-directional Filter Calculator:
 * - Center (0.5): FLAT (neutral bypass, full bandwidth)
 * - Left (< 0.5): Low-Pass Filter (from 20kHz down to 20Hz as slider moves to 0.0)
 * - Right (> 0.5): High-Pass Filter (from 20Hz up to 10kHz+ as slider moves to 1.0)
 */
export function calculateDJFilterState(sliderPos: number, resonanceQ = 2.0): DJFilterState {
  const deadband = 0.02; // Small center detent
  if (Math.abs(sliderPos - 0.5) <= deadband) {
    return {
      mode: 'flat',
      frequency: 20000,
      resonanceQ: 0.7,
    };
  }

  if (sliderPos < 0.5) {
    // Low-Pass mode: 0.0 -> 20Hz, 0.48 -> 20,000Hz
    const norm = (sliderPos / (0.5 - deadband));
    const freq = normalizedToLogHz(norm, 30, 20000);
    return {
      mode: 'lowpass',
      frequency: freq,
      resonanceQ,
    };
  } else {
    // High-Pass mode: 0.52 -> 20Hz, 1.0 -> 16,000Hz
    const norm = (sliderPos - (0.5 + deadband)) / (0.5 - deadband);
    const freq = normalizedToLogHz(norm, 20, 16000);
    return {
      mode: 'highpass',
      frequency: freq,
      resonanceQ,
    };
  }
}

/**
 * Generates an Overdrive / Distortion WaveShaper curve.
 * Based on hard-clipping arctangent / polynomial waveshaping.
 * @param drive - Drive amount from 0 (clean) to 100 (extreme industrial crunch)
 */
export function makeDistortionCurve(drive: number, nSamples = 4096): Float32Array {
  const curve = new Float32Array(nSamples);
  const k = typeof drive === 'number' ? Math.max(0, drive) : 0;

  if (k === 0) {
    // Pure linear passthrough
    for (let i = 0; i < nSamples; i++) {
      curve[i] = (i * 2) / nSamples - 1;
    }
    return curve;
  }

  // Industrial analog saturation curve with tanh warmth and hard-drive headroom
  const driveFactor = 1 + (k * 0.1);
  for (let i = 0; i < nSamples; i++) {
    const x = (i * 2) / nSamples - 1;
    curve[i] = Math.tanh(x * driveFactor);
  }

  return curve;
}

/**
 * Simulates bitcrushing sample truncation on a single float audio sample [-1.0, 1.0].
 * @param sample Audio sample [-1, 1]
 * @param bits Target bit depth (e.g. 4, 8, 12, 16)
 */
export function quantizeBitDepth(sample: number, bits: number): number {
  if (bits >= 16) return sample;
  const steps = Math.pow(2, bits);
  return Math.round(sample * steps) / steps;
}

/**
 * Calculates tempo-synced delay times in seconds.
 */
export function calculateDelaySeconds(
  bpm: number,
  division: '1/2' | '1/4' | '1/8' | '1/8T' | '1/16'
): number {
  const beatSec = 60 / bpm;
  switch (division) {
    case '1/2':
      return beatSec * 2;
    case '1/4':
      return beatSec;
    case '1/8':
      return beatSec * 0.5;
    case '1/8T':
      return (beatSec * 0.5) * (2 / 3); // triplet
    case '1/16':
      return beatSec * 0.25;
    default:
      return beatSec;
  }
}
