import React, { useState } from 'react';
import { usePWAInstall } from './usePWAInstall';
import { Download, Share, PlusSquare, X } from 'lucide-react';

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // If already running as an installed PWA, hide the button
  if (isInstalled) {
    return null;
  }

  // Chromium / Android / Desktop flow
  if (isInstallable) {
    return (
      <button
        onClick={install}
        className="flex items-center gap-1.5 rounded-lg bg-orange-600 px-3 py-1.5 text-xs font-mono font-medium text-white shadow-sm hover:bg-orange-500 transition"
      >
        <Download className="w-3.5 h-3.5" />
        INSTALL PWA
      </button>
    );
  }

  // iOS Safari flow
  if (isIOS) {
    return (
      <>
        <button
          onClick={() => setShowIOSGuide(true)}
          className="flex items-center gap-1.5 rounded-lg border border-[#2d333b] bg-[#181a1f] px-2.5 py-1 text-xs font-mono font-medium text-zinc-300 hover:text-white hover:bg-[#22262d] transition"
        >
          <Share className="w-3.5 h-3.5 text-orange-400" />
          INSTALL ON IOS
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
            <div className="w-full max-w-sm rounded-xl bg-[#121417] p-5 shadow-2xl border border-[#272c35] text-zinc-200 font-mono">
              <div className="flex items-center justify-between border-b border-[#20252e] pb-3 mb-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <PlusSquare className="w-4 h-4 text-orange-400" />
                  INSTALL KLANGSTRIPE ON IOS
                </h3>
                <button
                  onClick={() => setShowIOSGuide(false)}
                  className="p-1 rounded text-zinc-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-zinc-300 space-y-2 leading-relaxed">
                <span className="block">
                  1. Tap the <strong className="text-white">Share</strong> icon{' '}
                  <Share className="w-3.5 h-3.5 inline mx-1 text-sky-400" /> in Safari's bottom toolbar.
                </span>
                <span className="block">
                  2. Scroll down and tap{' '}
                  <strong className="text-white">Add to Home Screen</strong>.
                </span>
                <span className="block text-[11px] text-zinc-400">
                  Enables fullscreen zero-latency Web Audio API & Waveform Touch Stripe.
                </span>
              </p>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="mt-4 w-full rounded-lg bg-[#20242b] py-2 text-xs font-bold text-white hover:bg-[#2a303a] transition"
              >
                GOT IT
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
