import React, { useState, useEffect } from 'react';
import { audioEngine, EngineState } from '../audio/hard-techno-engine';
import { Compass, Clock, Zap, ArrowRight, Play, Pause } from 'lucide-react';

interface BarQuantizerProps {
  engineState: EngineState;
  onOpenAIMastermind: () => void;
}

export const BarQuantizer: React.FC<BarQuantizerProps> = ({
  engineState,
  onOpenAIMastermind,
}) => {
  const [transitionBars, setTransitionBars] = useState<16 | 32 | 64>(32);
  const [isAutomixRunning, setIsAutomixRunning] = useState(false);
  const [automixStep, setAutomixStep] = useState<string>('');

  const { bar, beat, sixteenth, barProgress, phrase32Progress } =
    engineState.barPosition;

  // Automated 32-bar transition protocol execution
  const executeQuantizedAutomix = () => {
    if (isAutomixRunning) {
      setIsAutomixRunning(false);
      setAutomixStep('');
      return;
    }

    setIsAutomixRunning(true);
    setAutomixStep('PHASE 1: Engaging 18dB HPF sweep on Active Drums');

    // Make sure engine is playing
    if (!engineState.isPlaying) {
      audioEngine.play();
    }

    const startBar = bar;
    const midBar = startBar + Math.floor(transitionBars / 2);
    const endBar = startBar + transitionBars;

    const interval = setInterval(() => {
      const currentBar = audioEngine.getState().barPosition.bar;

      // Phase 1 (First half): Filter sweep
      if (currentBar < midBar) {
        const progress = (currentBar - startBar) / (midBar - startBar);
        // Sweep filter from flat (0.5) to HPF (0.75)
        audioEngine.setFilterSlider(0.5 + progress * 0.25);
        setAutomixStep(`SWEEPING HPF (Bar ${currentBar}/${midBar})`);
      }
      // Phase 2: Acid stem swap
      else if (currentBar >= midBar && currentBar < endBar - 1) {
        audioEngine.soloStem('acid');
        audioEngine.setDistortionDrive(35);
        setAutomixStep(`ACID ISOLATED + DRIVE BOOST (Bar ${currentBar}/${endBar})`);
      }
      // Phase 3: Pre-drop freeze tail
      else if (currentBar >= endBar - 1 && currentBar < endBar) {
        if (!audioEngine.getState().reverbFreeze) {
          audioEngine.toggleReverbFreeze();
        }
        audioEngine.setStemLevel('drums', 0);
        setAutomixStep('FREEZING REVERB TAIL - DROP IMMINENT');
      }
      // Drop hit!
      else if (currentBar >= endBar) {
        // Slam drums back on full power, release freeze, reset filter
        audioEngine.setFilterSlider(0.5);
        audioEngine.setStemLevel('drums', 1.0);
        audioEngine.setStemLevel('acid', 1.0);
        audioEngine.setStemLevel('vocals', 0.9);
        if (audioEngine.getState().reverbFreeze) {
          audioEngine.toggleReverbFreeze();
        }
        setAutomixStep('DROP SLAMMED - FULL 155+ BPM RUMBLE');
        setIsAutomixRunning(false);
        clearInterval(interval);
      }
    }, 250);
  };

  return (
    <div className="bg-[#121417] border border-[#23272e] rounded-xl p-3 sm:p-4 shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 border-b border-[#1e2228] pb-2">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-300 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-sky-500" />
            AUTOMIX & BAR QUANTIZATION
          </span>
          <span className="text-[10px] font-mono text-zinc-500 hidden sm:inline">
            16 / 32 / 64 BARS PHRASE LOCK
          </span>
        </div>

        {/* AI MasterMind Trigger Button */}
        <button
          onClick={onOpenAIMastermind}
          className="flex items-center gap-1.5 px-3 py-1 rounded bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 border border-amber-500/30 text-xs font-mono font-bold transition-colors"
        >
          <Zap className="w-3.5 h-3.5" />
          AI ARCHITECT
        </button>
      </div>

      {/* Main Grid: Bar Counter + BPM & Pitch + Transition Trigger */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Module 1: High-Precision Bar & Phrase Position */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-zinc-400 mb-1">
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-sky-400" />
              TIMELINE POSITION
            </span>
            <span className="text-zinc-500">4/4 HARD TECHNO</span>
          </div>

          <div className="my-1 flex items-baseline gap-2">
            <div className="text-3xl sm:text-4xl font-mono font-black tracking-tight text-white tabular-nums">
              {String(bar).padStart(2, '0')}
            </div>
            <div className="text-xl sm:text-2xl font-mono text-zinc-500 font-bold tabular-nums">
              .{beat}.{sixteenth}
            </div>
            <div className="ml-auto text-right">
              <span className="text-[10px] font-mono text-zinc-500 block">32-BAR PHRASE</span>
              <span className="text-xs font-mono text-sky-400 font-bold">
                {Math.round(phrase32Progress * 100)}%
              </span>
            </div>
          </div>

          {/* Bar progress track */}
          <div className="w-full h-1.5 bg-[#0a0b0d] rounded-full overflow-hidden mt-1 border border-[#20242b]">
            <div
              className="h-full bg-sky-400 transition-all duration-75"
              style={{ width: `${barProgress * 100}%` }}
            />
          </div>
        </div>

        {/* Module 2: BPM & Harmonic Camelot Key */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-zinc-400 mb-1">
            <span className="flex items-center gap-1">
              <Compass className="w-3.5 h-3.5 text-amber-500" />
              BPM & HARMONIC KEY
            </span>
            <span className="text-emerald-400 font-bold text-[10px]">
              CAMELOT 8A / Am
            </span>
          </div>

          <div className="flex items-baseline justify-between my-1">
            <div className="text-2xl sm:text-3xl font-mono font-black text-white tabular-nums">
              {engineState.bpm}
              <span className="text-xs font-normal text-zinc-500 ml-1">BPM</span>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={() => audioEngine.setBpm(engineState.bpm - 1)}
                className="w-7 h-7 rounded bg-[#20242b] text-zinc-300 font-mono font-bold hover:text-white border border-[#2d333b]"
              >
                -
              </button>
              <button
                onClick={() => audioEngine.setBpm(engineState.bpm + 1)}
                className="w-7 h-7 rounded bg-[#20242b] text-zinc-300 font-mono font-bold hover:text-white border border-[#2d333b]"
              >
                +
              </button>
            </div>
          </div>

          {/* BPM Slider 140 to 175 */}
          <div className="pt-1">
            <input
              type="range"
              min="140"
              max="175"
              step="1"
              value={engineState.bpm}
              onChange={(e) => audioEngine.setBpm(parseInt(e.target.value, 10))}
              className="w-full"
              style={{ accentColor: '#ff5500' }}
              aria-label="Engine BPM tempo slider"
            />
          </div>
        </div>

        {/* Module 3: Bar-Quantized Automix Trigger */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-mono text-zinc-400 mb-1">
            <span>TRANSITION DURATION</span>
            {/* 16 / 32 / 64 Bar selector */}
            <div className="flex items-center gap-1">
              {([16, 32, 64] as const).map((b) => (
                <button
                  key={b}
                  onClick={() => setTransitionBars(b)}
                  className={`px-1.5 py-0.5 text-[9px] font-mono rounded font-bold ${
                    transitionBars === b
                      ? 'bg-amber-500 text-black'
                      : 'bg-[#20242b] text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {b}B
                </button>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <div className="my-1.5">
            <button
              onClick={executeQuantizedAutomix}
              className={`w-full py-2.5 px-3 rounded-lg font-mono font-bold text-xs flex items-center justify-center gap-2 border transition-all ${
                isAutomixRunning
                  ? 'bg-amber-500 text-black border-amber-300 shadow-[0_0_15px_rgba(245,158,11,0.5)]'
                  : 'bg-gradient-to-r from-red-600 to-amber-600 text-white border-red-500/50 hover:brightness-110 shadow-lg'
              }`}
            >
              <Zap className="w-4 h-4 fill-current" />
              {isAutomixRunning
                ? 'ABORT TRANSITION'
                : `EXECUTE ${transitionBars}-BAR DROP TRANSITION`}
            </button>
          </div>

          {/* Status text */}
          <p className="text-[10px] font-mono text-zinc-400 truncate">
            {isAutomixRunning ? (
              <span className="text-amber-400 font-bold animate-pulse">
                {automixStep}
              </span>
            ) : (
              'Quantized to structural measure: drop cuts & stem swaps'
            )}
          </p>
        </div>
      </div>
    </div>
  );
};
