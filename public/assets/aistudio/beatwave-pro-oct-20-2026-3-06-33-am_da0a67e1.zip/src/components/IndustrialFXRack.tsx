import React, { useState } from 'react';
import { audioEngine, EngineState } from '../audio/hard-techno-engine';
import { Sliders, Zap, Radio, Sparkles, RefreshCw } from 'lucide-react';

interface IndustrialFXRackProps {
  engineState: EngineState;
}

export const IndustrialFXRack: React.FC<IndustrialFXRackProps> = ({ engineState }) => {
  const [filterModeType, setFilterModeType] = useState<'dj_bidirectional' | 'swift_frequency'>('dj_bidirectional');
  const [rawFrequencyHz, setRawFrequencyHz] = useState<number>(20000);

  return (
    <div className="bg-[#121417] border border-[#23272e] rounded-xl p-3 sm:p-4 shadow-xl">
      {/* FX Header */}
      <div className="flex items-center justify-between mb-3 border-b border-[#1e2228] pb-2">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-300 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            INDUSTRIAL AUDIO FX PIPELINE
          </span>
          <span className="text-[10px] font-mono text-zinc-500 hidden sm:inline">
            SUPERPOWERED DSP CHAIN
          </span>
        </div>

        {/* Filter Mode Switcher */}
        <div className="flex items-center gap-1 bg-[#0c0d10] p-0.5 rounded border border-[#22272e]">
          <button
            onClick={() => setFilterModeType('dj_bidirectional')}
            className={`px-2 py-0.5 text-[10px] font-mono rounded transition-colors ${
              filterModeType === 'dj_bidirectional'
                ? 'bg-[#252a32] text-white font-bold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            DJ DUAL FILTER
          </button>
          <button
            onClick={() => setFilterModeType('swift_frequency')}
            className={`px-2 py-0.5 text-[10px] font-mono rounded transition-colors ${
              filterModeType === 'swift_frequency'
                ? 'bg-[#252a32] text-white font-bold'
                : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            DIRECT HZ (SWIFT)
          </button>
        </div>
      </div>

      {/* Grid of FX Units */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* FX 1: Superpowered Driven Filter */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-xs font-mono font-bold text-white">
                DRIVEN FILTER
              </span>
            </div>
            <span className="text-[11px] font-mono text-emerald-400 font-bold">
              {filterModeType === 'dj_bidirectional'
                ? engineState.filterMode === 'flat'
                  ? 'FLAT'
                  : `${engineState.filterMode.toUpperCase()} ${engineState.filterFrequency}Hz`
                : `${rawFrequencyHz} Hz`}
            </span>
          </div>

          <div className="my-2">
            {filterModeType === 'dj_bidirectional' ? (
              <>
                <div className="flex justify-between text-[9px] font-mono text-zinc-500 mb-1">
                  <span>LPF (BASS ONLY)</span>
                  <span className="text-zinc-400">CENTER (FLAT)</span>
                  <span>HPF (HIGH PASS)</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  defaultValue="0.5"
                  onChange={(e) => audioEngine.setFilterSlider(parseFloat(e.target.value))}
                  className="w-full filter-slider"
                  aria-label="Bi-directional DJ filter slider"
                />
              </>
            ) : (
              <>
                <div className="flex justify-between text-[9px] font-mono text-zinc-500 mb-1">
                  <span>20 Hz</span>
                  <span className="text-zinc-400">CUTOFF FREQUENCY</span>
                  <span>20000 Hz</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="20000"
                  step="10"
                  value={rawFrequencyHz}
                  onChange={(e) => {
                    const hz = parseInt(e.target.value, 10);
                    setRawFrequencyHz(hz);
                    audioEngine.setFilterFrequencyHz(hz);
                  }}
                  className="w-full filter-slider"
                  aria-label="Filter cutoff frequency slider in Hertz"
                />
              </>
            )}
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={() => {
                audioEngine.setFilterSlider(0.5);
                setRawFrequencyHz(20000);
                audioEngine.setFilterFrequencyHz(20000);
              }}
              className="text-[10px] font-mono text-zinc-400 hover:text-white flex items-center gap-1"
            >
              <RefreshCw className="w-2.5 h-2.5" /> RESET FLAT
            </button>
            <span className="text-[9px] font-mono text-zinc-600">
              Q: 1.5 RES
            </span>
          </div>
        </div>

        {/* FX 2: Industrial Overdrive / Distortion */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span className="text-xs font-mono font-bold text-white">
                HARD OVERDRIVE
              </span>
            </div>
            <span className="text-[11px] font-mono text-amber-400 font-bold">
              +{engineState.distortionAmount}%
            </span>
          </div>

          <div className="my-2">
            <div className="flex justify-between text-[9px] font-mono text-zinc-500 mb-1">
              <span>WARM TUBE</span>
              <span>INDUSTRIAL CRUNCH</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              step="1"
              value={engineState.distortionAmount}
              onChange={(e) =>
                audioEngine.setDistortionDrive(parseInt(e.target.value, 10))
              }
              className="w-full"
              style={{ accentColor: '#ff5500' }}
              aria-label="Distortion drive amount"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <button
              onClick={() => audioEngine.setDistortionDrive(45)}
              className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#20242b] text-amber-300 hover:bg-[#2b313b]"
            >
              BERLIN DRIVE
            </button>
            <button
              onClick={() => audioEngine.setDistortionDrive(0)}
              className="text-[10px] font-mono text-zinc-500 hover:text-zinc-300"
            >
              CLEAN
            </button>
          </div>
        </div>

        {/* FX 3: Tempo-Synced Feedback Delay */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-sky-400" />
              <span className="text-xs font-mono font-bold text-white">
                FEEDBACK DELAY
              </span>
            </div>
            <span className="text-[11px] font-mono text-sky-400 font-bold">
              1/4 TRIPLET
            </span>
          </div>

          <div className="grid grid-cols-4 gap-1 my-2">
            {(['1/2', '1/4', '1/8', '1/8T'] as const).map((div) => (
              <button
                key={div}
                onClick={() => audioEngine.setDelayDivision(div)}
                className="py-1 text-[10px] font-mono font-bold rounded bg-[#20242b] text-zinc-300 hover:text-white hover:bg-sky-950/60 hover:text-sky-400 border border-[#2d333b] transition-colors"
              >
                {div}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[9px] font-mono text-zinc-500">
              TEMPO SYNC ({engineState.bpm} BPM)
            </span>
            <span className="text-[9px] font-mono text-zinc-400">
              FB: 35%
            </span>
          </div>
        </div>

        {/* FX 4: Warehouse Reverb & Instant Tail Freeze */}
        <div className="p-3 rounded-lg bg-[#16181d] border border-[#22272e] flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span className="text-xs font-mono font-bold text-white">
                REVERB FREEZE
              </span>
            </div>
            <span
              className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                engineState.reverbFreeze
                  ? 'bg-purple-950 text-purple-300 border border-purple-600 animate-pulse'
                  : 'text-zinc-500'
              }`}
            >
              {engineState.reverbFreeze ? 'TAIL FROZEN' : 'ACTIVE TAIL'}
            </span>
          </div>

          <div className="my-1">
            <button
              onClick={() => audioEngine.toggleReverbFreeze()}
              className={`w-full py-2 px-3 rounded-lg font-mono font-bold text-xs flex items-center justify-center gap-2 border transition-all ${
                engineState.reverbFreeze
                  ? 'bg-purple-600 text-white border-purple-400 shadow-[0_0_15px_rgba(168,85,247,0.5)]'
                  : 'bg-[#20242b] text-purple-300 border-[#2d333b] hover:bg-purple-950/40 hover:border-purple-800'
              }`}
              title="Hold acoustic space infinitely before drop cut"
            >
              {engineState.reverbFreeze ? 'RELEASE FREEZE' : 'FREEZE REVERB TAIL'}
            </button>
          </div>

          <div className="flex items-center justify-between pt-1 text-[9px] font-mono text-zinc-500">
            <span>CONCRETE SPACE</span>
            <span>PRE-DROP KILL</span>
          </div>
        </div>
      </div>
    </div>
  );
};
