import React, { useRef } from 'react';
import { audioEngine, EngineState, TrackData } from '../audio/hard-techno-engine';
import { Disc, Upload, Music, Check } from 'lucide-react';

interface TrackDeckSelectorProps {
  engineState: EngineState;
  onCustomTrackLoaded: (track: TrackData) => void;
  currentTrackTitle: string;
}

export const TrackDeckSelector: React.FC<TrackDeckSelectorProps> = ({
  engineState,
  onCustomTrackLoaded,
  currentTrackTitle,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const curatedTracks = [
    {
      id: 'monolith',
      title: 'Monolith 909',
      bpm: 155,
      key: '8A (Am)',
      tag: 'RELENTLESS SUB-RUMBLE',
      desc: 'Raw warehouse 909 kick with heavy 42Hz sub rumble and rolling hats',
    },
    {
      id: 'acid_hex',
      title: 'Acid Hexagon 303',
      bpm: 158,
      key: '9A (Em)',
      tag: 'SCREAMING ACID',
      desc: 'Roland 303 resonant square wave sequences with rapid filter modulation',
    },
    {
      id: 'concrete_vault',
      title: 'Concrete Vault',
      bpm: 162,
      key: '4A (Fm)',
      tag: 'BERLIN INDUSTRIAL',
      desc: 'Heavy industrial distortion, metallic percussion, and vocal chops',
    },
  ];

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const trackData = await audioEngine.loadCustomAudioFile(file);
      onCustomTrackLoaded(trackData);
    } catch (err) {
      console.error('Failed to load custom audio file:', err);
    }
  };

  return (
    <div className="bg-[#121417] border border-[#23272e] rounded-xl p-3 sm:p-4 shadow-xl">
      <div className="flex items-center justify-between mb-3 border-b border-[#1e2228] pb-2">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-300 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-orange-500" />
            TRACK LIBRARY & AUDIO LOADER
          </span>
          <span className="text-[10px] font-mono text-zinc-500 hidden sm:inline">
            SWIFT loadTrack(url:) PARITY
          </span>
        </div>

        {/* Custom Upload Trigger */}
        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            onChange={handleFileUpload}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#1e2229] hover:bg-[#272d36] text-zinc-300 hover:text-white border border-[#2d333f] text-xs font-mono font-medium transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-orange-400" />
            LOAD MP3 / WAV
          </button>
        </div>
      </div>

      {/* Track Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
        {curatedTracks.map((track) => {
          const isSelected =
            engineState.activeTrackId === track.id &&
            engineState.activeTrackId !== 'custom';

          return (
            <button
              key={track.id}
              onClick={() => audioEngine.selectTrack(track.id)}
              className={`p-3 rounded-lg text-left border transition-all relative ${
                isSelected
                  ? 'bg-[#181b22] border-amber-500/60 shadow-[0_0_15px_rgba(255,85,0,0.15)]'
                  : 'bg-[#15171c] border-[#22272e] hover:border-[#2d333b]'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded bg-[#0d0e11] text-amber-400 border border-[#22272e]">
                  {track.tag}
                </span>
                <span className="text-[10px] font-mono text-zinc-500">
                  {track.key}
                </span>
              </div>

              <h4 className="text-xs font-mono font-bold text-white flex items-center justify-between">
                <span>{track.title}</span>
                {isSelected && (
                  <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                )}
              </h4>

              <p className="text-[10px] text-zinc-400 mt-1 line-clamp-2">
                {track.desc}
              </p>

              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 mt-2 pt-1.5 border-t border-[#1e2228]">
                <span>{track.bpm} BPM</span>
                <span>32 BARS</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
