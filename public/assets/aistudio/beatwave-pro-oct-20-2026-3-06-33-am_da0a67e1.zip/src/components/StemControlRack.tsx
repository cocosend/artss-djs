import React from 'react';
import { audioEngine, EngineState, StemLevels, StemMutes } from '../audio/hard-techno-engine';
import { Volume2, VolumeX, Mic, Activity, Disc } from 'lucide-react';

interface StemControlRackProps {
  engineState: EngineState;
}

export const StemControlRack: React.FC<StemControlRackProps> = ({ engineState }) => {
  const stems = [
    {
      id: 'drums' as keyof StemLevels,
      name: 'DRUMS / RUMBLE',
      subtext: '42Hz Sub-bass, 909 kicks, rolling hats',
      icon: Disc,
      color: '#ff5500',
      activeColor: 'text-amber-500',
      vuLevel: engineState.vuLevels.drums,
    },
    {
      id: 'acid' as keyof StemLevels,
      name: 'ACID / HARMONICS',
      subtext: '303 square sequences, resonant leads',
      icon: Activity,
      color: '#00ff66',
      activeColor: 'text-emerald-400',
      vuLevel: engineState.vuLevels.acid,
    },
    {
      id: 'vocals' as keyof StemLevels,
      name: 'VOCALS / FX',
      subtext: 'Industrial chops, risers, noise bursts',
      icon: Mic,
      color: '#38bdf8',
      activeColor: 'text-sky-400',
      vuLevel: engineState.vuLevels.vocals,
    },
  ];

  return (
    <div className="bg-[#121417] border border-[#23272e] rounded-xl p-3 sm:p-4 shadow-xl">
      <div className="flex items-center justify-between mb-3 border-b border-[#1e2228] pb-2">
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-300 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            3-STEM DYNAMIC ISOLATION
          </span>
          <span className="text-[10px] font-mono text-zinc-500 hidden sm:inline">
            REAL-TIME DSP ROUTING
          </span>
        </div>

        {/* Quick Stem Drop Action */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => audioEngine.toggleStemMute('drums')}
            className={`px-2.5 py-1 text-[10px] font-mono rounded font-bold transition-all border ${
              engineState.stemMutes.drums
                ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse'
                : 'bg-[#181a1f] text-zinc-300 border-[#262b33] hover:text-white'
            }`}
            title="Instant Bass Kill for Breakdowns and Drops"
          >
            {engineState.stemMutes.drums ? 'BASS MUTED' : 'KILL BASS'}
          </button>
          <button
            onClick={() => audioEngine.soloStem('acid')}
            className="px-2.5 py-1 text-[10px] font-mono rounded font-bold bg-[#181a1f] text-emerald-400 hover:bg-emerald-950/40 border border-[#262b33] transition-colors"
            title="Solo screaming 303 acid line"
          >
            SOLO 303
          </button>
        </div>
      </div>

      {/* 3 Stems Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {stems.map((stem) => {
          const isMuted = engineState.stemMutes[stem.id];
          const volume = engineState.stemLevels[stem.id];
          const Icon = stem.icon;

          return (
            <div
              key={stem.id}
              className={`p-3 rounded-lg border transition-all ${
                isMuted
                  ? 'bg-[#0f1013] border-red-950/40 opacity-70'
                  : 'bg-[#16181d] border-[#22272e]'
              }`}
            >
              {/* Stem Header */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-7 h-7 rounded flex items-center justify-center bg-[#0d0e11] border border-[#20242b]"
                    style={{ color: stem.color }}
                  >
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-mono font-bold tracking-tight text-white">
                      {stem.name}
                    </h4>
                    <p className="text-[10px] text-zinc-400 truncate max-w-[140px]">
                      {stem.subtext}
                    </p>
                  </div>
                </div>

                {/* Level % Display */}
                <span className="text-[11px] font-mono text-zinc-400 font-medium">
                  {isMuted ? 'MUTE' : `${Math.round(volume * 100)}%`}
                </span>
              </div>

              {/* VU Meter & Fader Row */}
              <div className="flex items-center gap-2.5 my-2.5">
                {/* Horizontal LED Peak Meter */}
                <div className="flex-1 h-2 bg-[#0c0d10] rounded-full overflow-hidden border border-[#20242b] p-0.5">
                  <div
                    className="h-full rounded-full transition-all duration-75"
                    style={{
                      width: isMuted ? '0%' : `${Math.min(100, stem.vuLevel * 100)}%`,
                      backgroundColor:
                        stem.vuLevel > 0.85
                          ? '#ff3344'
                          : stem.vuLevel > 0.6
                          ? '#ffaa00'
                          : stem.color,
                    }}
                  />
                </div>

                {/* Mute and Solo Controls */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => audioEngine.toggleStemMute(stem.id)}
                    className={`px-2 py-1 text-[10px] font-mono rounded font-bold transition-colors border ${
                      isMuted
                        ? 'bg-red-900/60 text-red-200 border-red-600'
                        : 'bg-[#20242b] text-zinc-300 hover:text-white border-[#2d333b]'
                    }`}
                    title="Mute stem"
                  >
                    MUTE
                  </button>
                  <button
                    onClick={() => audioEngine.soloStem(stem.id)}
                    className="px-2 py-1 text-[10px] font-mono rounded font-bold bg-[#20242b] text-zinc-300 hover:text-white hover:bg-emerald-950/60 hover:text-emerald-400 border border-[#2d333b] transition-colors"
                    title="Solo stem"
                  >
                    SOLO
                  </button>
                </div>
              </div>

              {/* Volume Slider */}
              <div className="flex items-center gap-2 pt-1">
                <Volume2 className="w-3.5 h-3.5 text-zinc-500 shrink-0" />
                <input
                  type="range"
                  min="0"
                  max="1.5"
                  step="0.02"
                  value={volume}
                  disabled={isMuted}
                  onChange={(e) =>
                    audioEngine.setStemLevel(stem.id, parseFloat(e.target.value))
                  }
                  className="w-full h-1 bg-[#1e2228] rounded-lg cursor-pointer"
                  style={{ accentColor: stem.color }}
                  aria-label={`${stem.name} volume fader`}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
