import React, { useRef, useEffect, useState, useCallback } from 'react';
import { audioEngine, EngineState } from '../audio/hard-techno-engine';
import { Play, Pause, FastForward, RotateCcw } from 'lucide-react';

interface WaveformTouchStripeProps {
  engineState: EngineState;
  customPeaks?: number[];
  cuePoints?: {
    breakCue: number; // e.g. 0.25
    dropCue: number;  // e.g. 0.50
    outroCue: number; // e.g. 0.875
  };
}

export const WaveformTouchStripe: React.FC<WaveformTouchStripeProps> = ({
  engineState,
  customPeaks,
  cuePoints = { breakCue: 0.25, dropCue: 0.5, outroCue: 0.875 },
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [isInteracting, setIsInteracting] = useState(false);
  const [pitchBendOffset, setPitchBendOffset] = useState(0); // -1 to 1

  // Default synthetic Hard Techno peaks if no custom audio uploaded
  const defaultPeaks = useRef<number[]>([]);
  if (defaultPeaks.current.length === 0) {
    const peaks: number[] = [];
    // 32-bar structural build/drop peak profile
    for (let i = 0; i < 240; i++) {
      const bar = (i / 240) * 32;
      let base = 0.5 + 0.3 * Math.sin(i * 0.4);
      // Intro (bars 1-8): driving kicks
      if (bar < 8) base = 0.5 + 0.25 * (i % 4 === 0 ? 1 : 0.4);
      // Breakdown (bars 9-16): atmospheric drop in bass
      else if (bar < 16) base = 0.3 + 0.2 * Math.sin(i * 0.2) + ((bar - 8) / 8) * 0.4;
      // Massive Drop (bars 17-24): full power kick rumble
      else if (bar < 24) base = 0.85 + 0.15 * (i % 2 === 0 ? 1 : 0.6);
      // Outro (bars 25-32): steady relentless groove
      else base = 0.65 + 0.2 * (i % 4 === 0 ? 1 : 0.5);

      peaks.push(Math.min(1.0, Math.max(0.12, base)));
    }
    defaultPeaks.current = peaks;
  }

  const activePeaks = customPeaks && customPeaks.length > 0 ? customPeaks : defaultPeaks.current;

  // Render Waveform Canvas with FDWaveformView style highlighting
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;

    if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
    }

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    // Background timeline grid lines
    ctx.strokeStyle = '#1e2227';
    ctx.lineWidth = 1;
    const totalBars = 32;
    for (let b = 1; b <= totalBars; b++) {
      const x = (b / totalBars) * width;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();

      // Major 8-bar markings
      if (b % 8 === 0) {
        ctx.fillStyle = '#495057';
        ctx.font = '10px "JetBrains Mono", monospace';
        ctx.fillText(`BAR ${b}`, x - 34, 12);
      }
    }

    // Horizontal center zero line
    ctx.strokeStyle = '#252a30';
    ctx.beginPath();
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();

    // Render waveform bars
    const peaks = activePeaks;
    const barWidth = Math.max(2, (width / peaks.length) - 1.2);
    const progressX = engineState.progress * width;

    for (let i = 0; i < peaks.length; i++) {
      const x = (i / peaks.length) * width;
      const peakHeight = Math.max(3, peaks[i] * (height * 0.78));
      const y = (height - peakHeight) / 2;

      // Color logic (Swift FDWaveformView parity):
      // Before playhead: highlighted in systemOrange (#ff5500)
      // After playhead: darkGray (#343a40 / #495057)
      if (x <= progressX) {
        ctx.fillStyle = '#ff5500'; // Active Hard Techno Orange
      } else {
        ctx.fillStyle = '#2b3036'; // Inactive Wave Dark Gray
      }

      ctx.fillRect(x, y, barWidth, peakHeight);
    }

    // Cue Point Markers
    const drawCueMarker = (percent: number, label: string, color: string) => {
      const cueX = percent * width;
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.beginPath();
      ctx.moveTo(cueX, 0);
      ctx.lineTo(cueX, height);
      ctx.stroke();
      ctx.setLineDash([]);

      // Marker Badge
      ctx.fillStyle = color;
      ctx.fillRect(cueX - 2, height - 16, 4, 16);
      ctx.font = '9px "JetBrains Mono", monospace';
      ctx.fillText(label, cueX + 4, height - 5);
    };

    drawCueMarker(cuePoints.breakCue, 'BREAK', '#38bdf8'); // Sky blue break
    drawCueMarker(cuePoints.dropCue, 'DROP 50%', '#ff3344'); // Crimson Drop
    drawCueMarker(cuePoints.outroCue, 'OUTRO', '#a855f7'); // Purple Outro

    // Needle Drop Playhead line (Bright Acid Green matching .systemGreen)
    ctx.strokeStyle = '#00ff66';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = 'rgba(0, 255, 102, 0.6)';
    ctx.shadowBlur = 8;
    ctx.beginPath();
    ctx.moveTo(progressX, 0);
    ctx.lineTo(progressX, height);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Needle drop triangle head
    ctx.fillStyle = '#00ff66';
    ctx.beginPath();
    ctx.moveTo(progressX - 6, 0);
    ctx.lineTo(progressX + 6, 0);
    ctx.lineTo(progressX, 8);
    ctx.closePath();
    ctx.fill();

    // Needle bottom marker
    ctx.beginPath();
    ctx.moveTo(progressX - 6, height);
    ctx.lineTo(progressX + 6, height);
    ctx.lineTo(progressX, height - 8);
    ctx.closePath();
    ctx.fill();

    ctx.restore();
  }, [engineState.progress, activePeaks, cuePoints]);

  // Touch & Pointer Gesture Engine (Needle Drop & Drag Scrubbing)
  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsInteracting(true);
    updatePositionFromPointer(e);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isInteracting) return;
    updatePositionFromPointer(e, true);
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    if (isInteracting) {
      e.currentTarget.releasePointerCapture(e.pointerId);
      setIsInteracting(false);
    }
  };

  const updatePositionFromPointer = (e: React.PointerEvent<HTMLDivElement>, isScrub = false) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(0, Math.min(rect.width, e.clientX - rect.left));
    const percent = x / rect.width;

    if (isScrub) {
      audioEngine.scrubTo(percent);
    } else {
      audioEngine.needleDrop(percent);
    }
  };

  // Pitch Bend Strip handlers (-16% to +16% pitch nudge)
  const handlePitchNudgeStart = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePitchNudgeMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (e.buttons === 1) {
      const rect = e.currentTarget.getBoundingClientRect();
      const relativeX = (e.clientX - rect.left) / rect.width; // 0 to 1
      const offset = (relativeX - 0.5) * 2; // -1 to 1
      setPitchBendOffset(offset);
      audioEngine.setPitchBend(offset);
    }
  };

  const handlePitchNudgeEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    setPitchBendOffset(0);
    audioEngine.releasePitchBend();
  };

  return (
    <div className="bg-[#121417] border border-[#23272e] rounded-xl p-3 sm:p-4 shadow-xl">
      {/* Top Stripe Header Bar */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-3">
          <span className="text-[11px] font-mono tracking-wider uppercase text-amber-500 font-semibold flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            WAVEFORM TOUCH STRIPE
          </span>
          <span className="text-xs font-mono text-zinc-400">
            BAR {String(engineState.barPosition.bar).padStart(2, '0')}.
            {engineState.barPosition.beat}.
            {engineState.barPosition.sixteenth}
          </span>
        </div>

        {/* Quick Needle Drop Preset Cues */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => audioEngine.needleDrop(cuePoints.breakCue)}
            className="px-2 py-0.5 text-[10px] font-mono rounded bg-[#1e2228] text-sky-400 hover:bg-[#282d35] transition-colors border border-[#2d333b]"
            title="Needle drop to Breakdown"
          >
            BREAK
          </button>
          <button
            onClick={() => audioEngine.needleDrop(cuePoints.dropCue)}
            className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-red-950/60 text-red-400 hover:bg-red-900/60 transition-colors border border-red-800/40"
            title="Needle drop straight into Drop"
          >
            DROP (50%)
          </button>
          <button
            onClick={() => audioEngine.needleDrop(cuePoints.outroCue)}
            className="px-2 py-0.5 text-[10px] font-mono rounded bg-[#1e2228] text-purple-400 hover:bg-[#282d35] transition-colors border border-[#2d333b]"
            title="Needle drop to Outro"
          >
            OUTRO
          </button>
        </div>
      </div>

      {/* Main Touch Stripe Canvas Container */}
      <div
        ref={containerRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="relative w-full h-28 sm:h-36 bg-[#0a0b0d] rounded-lg overflow-hidden border border-[#1e2228] cursor-crosshair touch-none select-none"
      >
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
        />

        {/* Interactive Scrubbing Tooltip */}
        {isInteracting && (
          <div
            className="absolute top-2 pointer-events-none transform -translate-x-1/2 bg-black/90 border border-amber-500/80 px-2 py-0.5 rounded text-[10px] font-mono text-amber-400 shadow-lg"
            style={{ left: `${engineState.progress * 100}%` }}
          >
            {(engineState.progress * 100).toFixed(1)}% / {(engineState.currentTime).toFixed(1)}s
          </div>
        )}
      </div>

      {/* Dynamic Touch-Drag Pitch Bend Stripe */}
      <div className="mt-2.5 flex items-center justify-between gap-2 pt-2 border-t border-[#1e2228]">
        <div className="flex items-center gap-1">
          <button
            onPointerDown={() => audioEngine.setPitchBend(-0.8)}
            onPointerUp={() => audioEngine.releasePitchBend()}
            className="px-2.5 py-1 text-[11px] font-mono rounded bg-[#181a1f] text-zinc-300 hover:bg-[#22262d] active:bg-amber-950 active:text-amber-400 transition-colors border border-[#262b33]"
            title="Temporary pitch slow (-8%)"
          >
            - BEND
          </button>
          <button
            onPointerDown={() => audioEngine.setPitchBend(0.8)}
            onPointerUp={() => audioEngine.releasePitchBend()}
            className="px-2.5 py-1 text-[11px] font-mono rounded bg-[#181a1f] text-zinc-300 hover:bg-[#22262d] active:bg-amber-950 active:text-amber-400 transition-colors border border-[#262b33]"
            title="Temporary pitch accelerate (+8%)"
          >
            + BEND
          </button>
        </div>

        {/* Dynamic touch-drag slider zone for phase alignment */}
        <div
          onPointerDown={handlePitchNudgeStart}
          onPointerMove={handlePitchNudgeMove}
          onPointerUp={handlePitchNudgeEnd}
          onPointerCancel={handlePitchNudgeEnd}
          className="flex-1 h-8 bg-[#0a0b0d] rounded border border-[#22272e] flex items-center justify-center relative touch-none cursor-ew-resize px-2"
          title="Drag left/right to bend pitch and align phase"
        >
          <div className="absolute inset-y-1 w-0.5 bg-zinc-600 left-1/2 -translate-x-1/2" />
          {pitchBendOffset !== 0 && (
            <div
              className={`absolute inset-y-1 rounded transition-all ${
                pitchBendOffset > 0 ? 'bg-amber-500/40 left-1/2' : 'bg-sky-500/40 right-1/2'
              }`}
              style={{
                width: `${Math.abs(pitchBendOffset) * 48}%`,
              }}
            />
          )}
          <span className="text-[10px] font-mono text-zinc-400 z-10 pointer-events-none text-center truncate px-1">
            {pitchBendOffset === 0
              ? 'TOUCH-DRAG TO PHASE ALIGN'
              : `PITCH BEND: ${(pitchBendOffset * 16).toFixed(1)}%`}
          </span>
        </div>

        <button
          onClick={() => audioEngine.needleDrop(0)}
          className="p-1.5 rounded bg-[#181a1f] text-zinc-400 hover:text-white hover:bg-[#22262d] transition-colors border border-[#262b33]"
          title="Reset to Start"
        >
          <RotateCcw className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
