import React, { useState } from 'react';
import { audioEngine, EngineState } from '../audio/hard-techno-engine';
import { Zap, X, Terminal, CheckCircle2, Play, Sliders } from 'lucide-react';

import {
  generateStandard32BarPlan,
  buildHardTechnoProtocolText,
} from '../audio/transition-protocol';

interface AIMasterMindModalProps {
  isOpen: boolean;
  onClose: () => void;
  engineState: EngineState;
  onApplyCuePoints?: (cues: { breakCue: number; dropCue: number; outroCue: number }) => void;
}

export const AIMasterMindModal: React.FC<AIMasterMindModalProps> = ({
  isOpen,
  onClose,
  engineState,
  onApplyCuePoints,
}) => {
  const [activeTrackName, setActiveTrackName] = useState('Monolith 909');
  const [activeBpm, setActiveBpm] = useState(155);
  const [activeKey, setActiveKey] = useState('8A (Am)');

  const [targetTrackName, setTargetTrackName] = useState('Acid Hexagon 303');
  const [targetBpm, setTargetBpm] = useState(158);
  const [targetKey, setTargetKey] = useState('9A (Em)');

  const [durationBars, setDurationBars] = useState(32);
  const [stylePreset, setStylePreset] = useState('Industrial Drop Slam');

  const [isLoading, setIsLoading] = useState(false);
  const [protocolOutput, setProtocolOutput] = useState<string | null>(() => {
    return buildHardTechnoProtocolText(
      generateStandard32BarPlan(
        { title: 'Monolith 909', bpm: 155, key: '8A (Am)' },
        { title: 'Acid Hexagon 303', bpm: 158, key: '9A (Em)' },
        32
      )
    );
  });
  const [isArmed, setIsArmed] = useState(false);

  if (!isOpen) return null;

  const presets = [
    {
      name: 'Klangkuenstler Peak Time Slam',
      active: { title: 'Raw Monolith', bpm: 160, key: '8A (Am)' },
      target: { title: 'Tension 303', bpm: 160, key: '9A (Em)' },
      style: 'Relentless Peak Drop Slam',
      bars: 32,
    },
    {
      name: 'I Hate Models Acid Meltdown',
      active: { title: 'Bleeding Heart', bpm: 155, key: '8A (Am)' },
      target: { title: 'Warehouse Acid Hex', bpm: 156, key: '8B (C)' },
      style: '303 Filter Resonance Sweep',
      bars: 32,
    },
    {
      name: 'Kobosil Industrial Concrete Rumble',
      active: { title: 'Concrete Vault', bpm: 158, key: '4A (Fm)' },
      target: { title: 'Ostgut Hammer', bpm: 160, key: '5A (Cm)' },
      style: 'Sub-bass Rumble Swap',
      bars: 16,
    },
  ];

  const loadPreset = (p: (typeof presets)[0]) => {
    setActiveTrackName(p.active.title);
    setActiveBpm(p.active.bpm);
    setActiveKey(p.active.key);
    setTargetTrackName(p.target.title);
    setTargetBpm(p.target.bpm);
    setTargetKey(p.target.key);
    setStylePreset(p.style);
    setDurationBars(p.bars);
    setIsArmed(false);
    setProtocolOutput(
      buildHardTechnoProtocolText(
        generateStandard32BarPlan(
          { title: p.active.title, bpm: p.active.bpm, key: p.active.key },
          { title: p.target.title, bpm: p.target.bpm, key: p.target.key },
          p.bars
        )
      )
    );
  };

  const handleGenerateProtocol = async () => {
    setIsLoading(true);
    setProtocolOutput(null);

    try {
      const response = await fetch('/api/ai/transition-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          activeTrack: {
            title: activeTrackName,
            bpm: activeBpm,
            key: activeKey,
          },
          targetTrack: {
            title: targetTrackName,
            bpm: targetBpm,
            key: targetKey,
          },
          durationBars,
          style: stylePreset,
        }),
      });

      const data = await response.json();
      if (data.success && data.protocolText) {
        setProtocolOutput(data.protocolText);
      } else {
        setProtocolOutput('Failed to generate protocol. Please try again.');
      }
    } catch (err) {
      console.error(err);
      setProtocolOutput('Connection error while contacting AI Sound Architect.');
    } finally {
      setIsLoading(false);
    }
  };

  const armProtocolIntoEngine = () => {
    setIsArmed(true);
    if (onApplyCuePoints) {
      onApplyCuePoints({
        breakCue: 0.25,
        dropCue: 0.5,
        outroCue: 0.875,
      });
    }
    // Set target track BPM
    audioEngine.setBpm(activeBpm);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md">
      <div className="bg-[#101215] border border-[#272c35] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#1e2229] bg-[#14161b]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Zap className="w-4 h-4 fill-current" />
            </div>
            <div>
              <h3 className="text-sm font-mono font-bold text-white tracking-wide">
                AI HARD TECHNO MASTERMIND
              </h3>
              <p className="text-[10px] font-mono text-zinc-400">
                Underground Sound Architect & Stem Transition Intelligence
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-[#20252d] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 text-xs font-mono">
          {/* Quick Preset Selector */}
          <div>
            <label className="text-[11px] text-zinc-400 font-bold block mb-1.5">
              UNDERGROUND STYLE PRESETS:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {presets.map((preset) => (
                <button
                  key={preset.name}
                  onClick={() => loadPreset(preset)}
                  className="p-2 text-left rounded-lg bg-[#16181f] border border-[#232731] hover:border-amber-500/50 hover:bg-[#1b1e27] transition-all"
                >
                  <span className="text-[11px] font-bold text-amber-400 block truncate">
                    {preset.name}
                  </span>
                  <span className="text-[9px] text-zinc-500 block">
                    {preset.bars} Bars · {preset.active.bpm} BPM · {preset.style}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Active & Target Track Setup */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 rounded-xl bg-[#14161b] border border-[#20252e]">
            {/* Active Track */}
            <div className="space-y-2">
              <span className="text-[10px] text-amber-500 font-bold block">
                ACTIVE TRACK (DECK A)
              </span>
              <input
                type="text"
                value={activeTrackName}
                onChange={(e) => setActiveTrackName(e.target.value)}
                placeholder="Track Title"
                className="w-full px-2.5 py-1.5 rounded bg-[#0c0d10] border border-[#262b35] text-white text-xs"
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  value={activeBpm}
                  onChange={(e) => setActiveBpm(parseInt(e.target.value, 10))}
                  placeholder="BPM"
                  className="w-1/2 px-2.5 py-1.5 rounded bg-[#0c0d10] border border-[#262b35] text-white text-xs"
                />
                <input
                  type="text"
                  value={activeKey}
                  onChange={(e) => setActiveKey(e.target.value)}
                  placeholder="Key (e.g. 8A)"
                  className="w-1/2 px-2.5 py-1.5 rounded bg-[#0c0d10] border border-[#262b35] text-white text-xs"
                />
              </div>
            </div>

            {/* Target Track */}
            <div className="space-y-2">
              <span className="text-[10px] text-sky-400 font-bold block">
                TARGET TRACK (DECK B)
              </span>
              <input
                type="text"
                value={targetTrackName}
                onChange={(e) => setTargetTrackName(e.target.value)}
                placeholder="Track Title"
                className="w-full px-2.5 py-1.5 rounded bg-[#0c0d10] border border-[#262b35] text-white text-xs"
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  value={targetBpm}
                  onChange={(e) => setTargetBpm(parseInt(e.target.value, 10))}
                  placeholder="BPM"
                  className="w-1/2 px-2.5 py-1.5 rounded bg-[#0c0d10] border border-[#262b35] text-white text-xs"
                />
                <input
                  type="text"
                  value={targetKey}
                  onChange={(e) => setTargetKey(e.target.value)}
                  placeholder="Key (e.g. 9A)"
                  className="w-1/2 px-2.5 py-1.5 rounded bg-[#0c0d10] border border-[#262b35] text-white text-xs"
                />
              </div>
            </div>
          </div>

          {/* Action Trigger */}
          <div className="flex items-center gap-3">
            <button
              onClick={handleGenerateProtocol}
              disabled={isLoading}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-lg disabled:opacity-50 transition-all"
            >
              <Zap className="w-4 h-4 fill-current" />
              {isLoading
                ? 'GENERATING HARD TECHNO PROTOCOL...'
                : 'GENERATE TRANSITION PROTOCOL'}
            </button>
          </div>

          {/* Protocol Output Container */}
          {protocolOutput && (
            <div className="rounded-xl bg-[#090a0d] border border-[#222833] p-4 text-xs font-mono space-y-3">
              <div className="flex items-center justify-between border-b border-[#1c212a] pb-2">
                <span className="text-[11px] text-zinc-400 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                  ARCHITECT PROTOCOL RESULT
                </span>
                <button
                  onClick={armProtocolIntoEngine}
                  className={`px-3 py-1 rounded text-[11px] font-bold flex items-center gap-1.5 border transition-all ${
                    isArmed
                      ? 'bg-emerald-500 text-black border-emerald-400'
                      : 'bg-[#181d26] text-amber-400 border-amber-500/40 hover:bg-amber-500/20'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {isArmed ? 'PROTOCOL ARMED' : 'ARM INTO ENGINE'}
                </button>
              </div>

              <pre className="whitespace-pre-wrap text-zinc-300 leading-relaxed font-mono select-text bg-[#07080a] p-3 rounded-lg border border-[#161a22] text-[11px]">
                {protocolOutput}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
