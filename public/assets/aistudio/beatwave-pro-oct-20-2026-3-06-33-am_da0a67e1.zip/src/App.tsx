import React, { useState, useEffect } from 'react';
import { audioEngine, EngineState, TrackData } from './audio/hard-techno-engine';
import { WaveformTouchStripe } from './components/WaveformTouchStripe';
import { StemControlRack } from './components/StemControlRack';
import { IndustrialFXRack } from './components/IndustrialFXRack';
import { BarQuantizer } from './components/BarQuantizer';
import { TrackDeckSelector } from './components/TrackDeckSelector';
import { AIMasterMindModal } from './components/AIMasterMindModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import {
  Play,
  Pause,
  Disc,
  Activity,
  Zap,
  Sliders,
  Volume2,
  Cpu,
  Layers,
  Info,
} from 'lucide-react';

export default function App() {
  const [engineState, setEngineState] = useState<EngineState>(audioEngine.getState());
  const [currentTrack, setCurrentTrack] = useState<TrackData>({
    id: 'monolith',
    title: 'Monolith 909',
    bpm: 155,
    key: '8A (Am)',
    genre: 'Industrial Underground',
    barsTotal: 32,
  });

  const [cuePoints, setCuePoints] = useState({
    breakCue: 0.25,
    dropCue: 0.5,
    outroCue: 0.875,
  });

  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [needsAudioUnlock, setNeedsAudioUnlock] = useState(true);

  // Subscribe to audio engine ticks (60fps synced with Web Audio API)
  useEffect(() => {
    const unsubscribe = audioEngine.subscribe((state) => {
      setEngineState(state);
      if (state.isPlaying) {
        setNeedsAudioUnlock(false);
      }
    });
    return unsubscribe;
  }, []);

  const handleStartAudio = async () => {
    await audioEngine.initAudio();
    setNeedsAudioUnlock(false);
    audioEngine.play();
  };

  const handleCustomTrackLoaded = (track: TrackData) => {
    setCurrentTrack(track);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const ms = Math.floor((seconds % 1) * 10);
    return `${mins}:${String(secs).padStart(2, '0')}.${ms}`;
  };

  return (
    <div className="min-h-screen bg-[#0c0d0e] text-[#f1f3f5] flex flex-col selection:bg-amber-500 selection:text-black">
      {/* 1. TOP BAR CONTRACT */}
      <header className="flex items-center justify-between gap-8 px-4 sm:px-8 py-3.5 border-b border-[#1c2026] bg-[#101215]/90 backdrop-blur-md sticky top-0 z-40">
        {/* Zone 1: Single element brand wordmark */}
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center text-black font-black text-sm shadow-md">
            KS
          </div>
          <span className="text-base sm:text-lg font-mono font-extrabold tracking-tight text-white uppercase">
            KLANGSTRIPE
          </span>
          <span className="hidden sm:inline-block text-[10px] font-mono px-2 py-0.5 rounded bg-[#1c2027] text-zinc-400 border border-[#272d37]">
            HARD TECHNO PWA
          </span>
        </div>

        {/* Zone 2: Navigation anchor links */}
        <nav className="hidden lg:flex items-center gap-6 text-xs font-mono text-zinc-400">
          <a href="#touch-stripe" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Waveform Stripe
          </a>
          <a href="#stem-rack" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            3-Stem Isolation
          </a>
          <a href="#fx-rack" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Driven FX
          </a>
          <a href="#automix" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Bar Quantizer
          </a>
          <button
            onClick={() => setIsAIModalOpen(true)}
            className="text-amber-400 hover:text-amber-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1 font-bold"
          >
            <Zap className="w-3.5 h-3.5" />
            AI MasterMind
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <PWAInstallButton />
          <button
            onClick={() => setIsAIModalOpen(true)}
            className="lg:hidden p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs font-mono font-bold"
            title="Open AI MasterMind"
          >
            <Zap className="w-4 h-4 fill-current" />
          </button>
        </div>
      </header>

      {/* iOS Safari Web Audio Initialization Notice / Gesture Unlock */}
      {needsAudioUnlock && (
        <div className="bg-gradient-to-r from-amber-950/80 via-[#1c1813] to-amber-950/80 border-b border-amber-800/40 px-4 py-2.5 text-center flex items-center justify-center gap-3">
          <span className="text-xs font-mono text-amber-300">
            iOS Safari Web Audio API requires initial touch gesture
          </span>
          <button
            onClick={handleStartAudio}
            className="px-3 py-1 rounded bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-xs shadow-md transition-all active:scale-95"
          >
            INITIALIZE AUDIO ENGINE
          </button>
        </div>
      )}

      {/* MAIN CONTAINER */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 lg:p-8 space-y-4 sm:space-y-6">
        {/* Track Title, Primary Transport (Swift parity), and Telemetry HUD */}
        <div className="bg-[#121417] border border-[#23272e] rounded-xl p-4 sm:p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Track Info */}
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="w-12 h-12 rounded-xl bg-[#181a1f] border border-[#292f39] flex items-center justify-center text-amber-500 shadow-inner">
              <Disc className={`w-6 h-6 ${engineState.isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-xl font-mono font-extrabold text-white tracking-tight">
                  {currentTrack.title}
                </h1>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                  {engineState.bpm} BPM
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs font-mono text-zinc-400 mt-0.5">
                <span>Key: {currentTrack.key}</span>
                <span>·</span>
                <span>4/4 Time</span>
                <span>·</span>
                <span>{formatTime(engineState.currentTime)} / {formatTime(engineState.duration)}</span>
              </div>
            </div>
          </div>

          {/* Center: Big Bold Primary PLAY Button (Swift DJPlayerViewController Parity) */}
          {/* In Swift reference: playButton.backgroundColor = .systemGreen, 140x50px, bold font 22 */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-center">
            <button
              onClick={() => audioEngine.togglePlay()}
              className={`w-full sm:w-44 h-12 sm:h-14 rounded-xl font-mono font-black text-base sm:text-lg flex items-center justify-center gap-2.5 transition-all shadow-lg active:scale-95 ${
                engineState.isPlaying
                  ? 'bg-amber-600 hover:bg-amber-500 text-black shadow-amber-600/30'
                  : 'bg-[#10b981] hover:bg-[#059669] text-white shadow-emerald-500/30'
              }`}
              aria-label={engineState.isPlaying ? 'Pause Hard Techno playback' : 'Play Hard Techno track'}
            >
              {engineState.isPlaying ? (
                <>
                  <Pause className="w-5 h-5 fill-current" />
                  PAUSE
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current" />
                  PLAY
                </>
              )}
            </button>
          </div>

          {/* Quick HUD Metrics */}
          <div className="hidden lg:flex items-center gap-4 text-xs font-mono">
            <div className="text-right">
              <span className="text-[10px] text-zinc-500 block">BAR MEASURE</span>
              <span className="text-base font-bold text-white tabular-nums">
                {String(engineState.barPosition.bar).padStart(2, '0')}.{engineState.barPosition.beat}
              </span>
            </div>
            <div className="w-px h-8 bg-[#23272e]" />
            <div className="text-right">
              <span className="text-[10px] text-zinc-500 block">FILTER CUTOFF</span>
              <span className="text-base font-bold text-emerald-400 tabular-nums">
                {engineState.filterMode === 'flat' ? 'FLAT' : `${engineState.filterFrequency}Hz`}
              </span>
            </div>
            <div className="w-px h-8 bg-[#23272e]" />
            <div className="text-right">
              <span className="text-[10px] text-zinc-500 block">DRIVE HEADROOM</span>
              <span className="text-base font-bold text-amber-500 tabular-nums">
                +{engineState.distortionAmount}%
              </span>
            </div>
          </div>
        </div>

        {/* SECTION 1: WAVEFORM TOUCH STRIPE (Central Gesture Controller) */}
        <section id="touch-stripe" aria-label="Waveform Touch Stripe timeline navigation">
          <WaveformTouchStripe
            engineState={engineState}
            customPeaks={currentTrack.waveformPeaks}
            cuePoints={cuePoints}
          />
        </section>

        {/* SECTION 2: 3-STEM DYNAMIC ISOLATION RACK */}
        <section id="stem-rack" aria-label="3-Stem dynamic isolation rack">
          <StemControlRack engineState={engineState} />
        </section>

        {/* SECTION 3: INDUSTRIAL AUDIO FX PIPELINE */}
        <section id="fx-rack" aria-label="Industrial Audio FX pipeline">
          <IndustrialFXRack engineState={engineState} />
        </section>

        {/* SECTION 4: AUTOMIX & BAR QUANTIZATION */}
        <section id="automix" aria-label="High-BPM automix and bar quantization">
          <BarQuantizer
            engineState={engineState}
            onOpenAIMastermind={() => setIsAIModalOpen(true)}
          />
        </section>

        {/* SECTION 5: TRACK LIBRARY & AUDIO UPLOADER */}
        <section id="track-library" aria-label="Track library and audio loader">
          <TrackDeckSelector
            engineState={engineState}
            onCustomTrackLoaded={handleCustomTrackLoaded}
            currentTrackTitle={currentTrack.title}
          />
        </section>
      </main>

      {/* FOOTER */}
      <footer className="border-t border-[#1c2026] bg-[#0c0d0e] py-4 px-4 sm:px-8 text-center text-xs font-mono text-zinc-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>KlangStripe · AI Hard Techno Sound Architect</span>
          <span className="text-[11px] text-zinc-600">
            Web Audio API · Superpowered DSP Graph · iOS Safari Touch Stripe Architecture
          </span>
        </div>
      </footer>

      {/* AI MasterMind Modal */}
      <AIMasterMindModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
        engineState={engineState}
        onApplyCuePoints={(cues) => setCuePoints(cues)}
      />
    </div>
  );
}
