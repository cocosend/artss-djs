import fs from 'node:fs';
import zlib from 'node:zlib';

function createPNG(width, height, r, g, b) {
  // Create an RGBA buffer with a stylish dark techno pattern
  const rowSize = width * 4 + 1;
  const raw = Buffer.alloc(rowSize * height);

  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    raw[rowOffset] = 0; // Filter type: None
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      
      // Border and background
      const isBorder = x < 12 || x >= width - 12 || y < 12 || y >= height - 12;
      const isCenterPlayhead = Math.abs(x - width / 2) < 3;
      
      // Waveform bars simulation
      const barWidth = Math.max(2, Math.floor(width / 24));
      const barIndex = Math.floor(x / (barWidth + 2));
      const inBar = (x % (barWidth + 2)) < barWidth && x > 20 && x < width - 20;
      
      const barHeights = [
        0.2, 0.4, 0.7, 0.5, 0.3, 0.8, 0.95, 0.6,
        0.5, 0.3, 0.8, 0.6, 0.4, 0.7, 0.3, 0.2
      ];
      const hNorm = barHeights[barIndex % barHeights.length] || 0.4;
      const barH = (height * 0.7) * hNorm;
      const inHeight = Math.abs(y - height / 2) < barH / 2;

      if (isCenterPlayhead) {
        // Bright Acid Green Playhead
        raw[pxOffset] = 0;
        raw[pxOffset + 1] = 255;
        raw[pxOffset + 2] = 102;
        raw[pxOffset + 3] = 255;
      } else if (inBar && inHeight) {
        // Orange / Amber waveform stripe
        raw[pxOffset] = 255;
        raw[pxOffset + 1] = x < width / 2 ? 85 : 140;
        raw[pxOffset + 2] = 0;
        raw[pxOffset + 3] = 255;
      } else if (isBorder) {
        raw[pxOffset] = 40;
        raw[pxOffset + 1] = 45;
        raw[pxOffset + 2] = 52;
        raw[pxOffset + 3] = 255;
      } else {
        // Dark Obsidian
        raw[pxOffset] = 12;
        raw[pxOffset + 1] = 13;
        raw[pxOffset + 2] = 14;
        raw[pxOffset + 3] = 255;
      }
    }
  }

  const compressed = zlib.deflateSync(raw);

  // CRC32 calculation
  const crcTable = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    crcTable[n] = c;
  }
  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    const combined = Buffer.concat([typeBuf, data]);
    crcBuf.writeUInt32BE(crc32(combined), 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData[8] = 8; // bit depth
  ihdrData[9] = 6; // RGBA
  ihdrData[10] = 0; // compression
  ihdrData[11] = 0; // filter
  ihdrData[12] = 0; // interlace

  const ihdr = makeChunk('IHDR', ihdrData);
  const idat = makeChunk('IDAT', compressed);
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

if (!fs.existsSync('public')) {
  fs.mkdirSync('public');
}

fs.writeFileSync('public/pwa-192x192.png', createPNG(192, 192));
fs.writeFileSync('public/pwa-512x512.png', createPNG(512, 512));
fs.writeFileSync('public/apple-touch-icon.png', createPNG(180, 180));
console.log('PNG Icons successfully generated.');
