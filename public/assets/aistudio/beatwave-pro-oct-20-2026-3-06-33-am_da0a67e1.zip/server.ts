import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json());

// Initialize Gemini client if API key is present
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// System prompt from AI Hard Techno MasterMind specifications
const HARD_TECHNO_SYSTEM_INSTRUCTION = `ROLE AND CORE OBJECTIVE:
You are AI Underground Sound Architect, an ultra-optimized audio processing, stem isolation, and structural transition AI built specifically for Hard Techno, Acid Techno, Dark Techno, and Industrial Underground sets. Your engine is designed for mobile Web Audio API environments (iOS Safari PWA), prioritizing low latency and high-precision timeline navigation through a minimalist Waveform Touch Stripe interface.
Your objective is to execute relentless, high-energy stem transitions, manage bar-quantized structural drops, and apply heavy industrial FX algorithms while navigating audio strictly via linear touch-stripe scrubbing, needle drops, and pitch-bending.

TECHNICAL CONSTRAINTS & PERFORMANCE OPTIMIZATION:
- Target Runtime: iOS Mobile PWA (Safari WebKit / Web Audio API).
- Control Interface: Waveform Touch Stripe Architecture replacing dynamic platters/decks with a single linear gesture stripe for instant needle dropping, scrubbing, and phase-alignment.
- Stem Routing: 3-Stem dynamic control (Drums/Rumble, Acid/Harmonics, Vocals/FX) mapped directly alongside Touch Stripe position markers.
- BPM Domain: Fast & Relentless (140 BPM to 165+ BPM).
- Sound Aesthetic: Dark, distorted, acid-heavy, raw underground energy.

CORE ENGINE MODULES:
1. Waveform Touch Stripe & Stem Navigation:
- Touch Stripe Navigation: Instant scrubbing, drop-cue jumping (needle drop), and dynamic touch-drag pitch bending along the active audio timeline.
- Drums & Rumble: Sub-bass rumble, industrial kicks, punchy snares, and closed hats.
- Acid & Harmonics: 303 synth lines, dark stabs, resonant lead sequences, and distorted basslines.
- Vocals & FX: Spoken/screamed underground vocals, dark atmospheres, risers, and industrial noise.
2. High-BPM Automix & Bar Quantization:
- BPM & Key Alignment: Match pitch and harmonic structures within minor, phrygian, or dark scales using the Camelot Wheel.
- Grid Precision (16/32/64 Bars): Quantize all touch-stripe markers, stem swaps, and FX triggers strictly to structural measures (drop cuts, breakdowns, builds).
- Phase Lock: Calculate precise time-stretch percentages during touch-stripe scrubbing to maintain zero phase cancellation in the sub-rumble band.
3. Industrial Audio FX Pipeline:
- Driven Filters: High-Resonance High-Pass Filters (HPF) for rapid tension builds and Low-Pass Filters (LPF) for frequency isolation.
- Hard Audio Processing: Overdrive/Distortion, Bitcrushing, Feedback Delay (1/2, 1/4, 1/8 triplets), and Reverb Freeze (for instant spatial tails before hard cuts).

OUTPUT FORMAT:
When asked to process, transition, or create an FX execution strategy for tracks, return response strictly following this template:
⚡ HARD TECHNO STEM & STRIPE ANALYSIS
Active Track: [Title] — BPM: [140–165+] | Key: [Camelot / Dark Scale]
Target Track: [Title] — BPM: [140–165+] | Key: [Camelot / Dark Scale]
Touch Stripe Cue Points: [Drop Cue %, Break Cue %, Outro Cue %]
Stem Profile:
Drums/Rumble: [Sub-rumble status and kick energy]
Acid/Harmonics: [Synth activity and resonance level]
Vocals/FX: [Industrial atmosphere density]

🎛️ WAVEFORM TOUCH STRIPE TRANSITION PROTOCOL
Transition Duration: [e.g., 32 Bars / Touch-stripe Scrub to Bar 16 Drop]
Step-by-Step Timeline:
1. [Bar 1–8]: [Action: e.g., Drag Touch Stripe to Target Intro Marker; Low-cut active Drums/Rumble]
2. [Bar 9–16]: [Action: e.g., Pitch-bend Target via Touch Stripe to align grid; swap Acid Stem on bar 16 beat 4]
3. [Bar 17–32]: [Action: e.g., Hard mute Active Drums; slam Target Drums/Rumble via instant touch drop]

💥 HARD FX & DRIVE EXECUTION
Filter & Drive: [e.g., Engage Resonant HPF sweep + 15% Overdrive on Acid Stem]
Spatial Modulation: [e.g., 1/4 Feedback Delay + Reverb Freeze tail kill at Bar 32, Drop into raw Kick Rumble]`;

app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    engine: 'KlangStripe Web Audio DSP',
    geminiActive: !!aiClient,
    runtime: 'Node.js Express + WebKit PWA',
  });
});

app.post('/api/ai/transition-plan', async (req, res) => {
  try {
    const {
      activeTrack = { title: 'Raw Monolith', bpm: 155, key: '8A (Am)' },
      targetTrack = { title: 'Acid Hex 303', bpm: 158, key: '9A (Em)' },
      durationBars = 32,
      style = 'Industrial Drop Slam',
    } = req.body || {};

    if (aiClient) {
      const prompt = `Generate a high-octane Hard Techno transition protocol between:
Active Track: ${activeTrack.title} (BPM: ${activeTrack.bpm}, Key: ${activeTrack.key})
Target Track: ${targetTrack.title} (BPM: ${targetTrack.bpm}, Key: ${targetTrack.key})
Transition Duration: ${durationBars} Bars
Style / Flavor: ${style}
Focus on high-precision Waveform Touch Stripe scrubbing, needle drop cues, 3-stem isolation (Drums/Rumble, Acid/Harmonics, Vocals/FX), and industrial FX pipeline (Resonant HPF sweep, Overdrive, Bitcrusher, Reverb Freeze).`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          systemInstruction: HARD_TECHNO_SYSTEM_INSTRUCTION,
          temperature: 0.8,
        },
      });

      const text = response.text || '';
      return res.json({
        success: true,
        protocolText: text,
        activeTrack,
        targetTrack,
        durationBars,
      });
    }

    // High-performance algorithmic fallback conforming precisely to the template
    const algorithmicResponse = `⚡ HARD TECHNO STEM & STRIPE ANALYSIS
Active Track: ${activeTrack.title} — BPM: ${activeTrack.bpm} | Key: ${activeTrack.key}
Target Track: ${targetTrack.title} — BPM: ${targetTrack.bpm} | Key: ${targetTrack.key}
Touch Stripe Cue Points: Drop Cue 50.0%, Break Cue 25.0%, Outro Cue 87.5%
Stem Profile:
Drums/Rumble: Heavy 909 sub-bass compression, 42Hz resonant rumble floor, high kick velocity
Acid/Harmonics: Roland 303 square wave screaming through driven resonance at 1.8kHz
Vocals/FX: Industrial metallic reverberations, clipped spoken vocal chops, white noise sweeps

🎛️ WAVEFORM TOUCH STRIPE TRANSITION PROTOCOL
Transition Duration: ${durationBars} Bars / Touch-stripe Scrub to Bar ${Math.floor(durationBars / 2)} Drop
Step-by-Step Timeline:
1. [Bar 1–${Math.floor(durationBars / 4)}]: Drag Touch Stripe on Target to cue marker; engage 12dB/oct High-Pass filter on Active Drums/Rumble to carve out sub-room.
2. [Bar ${Math.floor(durationBars / 4) + 1}–${Math.floor(durationBars / 2)}]: Pitch-bend Target via Touch Stripe to lock phase; cross-fade Acid/Harmonics stem at Bar ${Math.floor(durationBars / 2)} beat 4.
3. [Bar ${Math.floor(durationBars / 2) + 1}–${durationBars}]: Hard mute Active Drums/Rumble; slam Target Drums/Rumble via instant touch drop; sweep HPF down to 20Hz.

💥 HARD FX & DRIVE EXECUTION
Filter & Drive: Engage Resonant HPF sweep from 200Hz to 2.4kHz with +18% tube overdrive on Acid Stem.
Spatial Modulation: 1/4 triplet feedback delay + Reverb Freeze tail kill at Bar ${durationBars}, Drop straight into raw distorted 155+ BPM Kick Rumble!`;

    return res.json({
      success: true,
      protocolText: algorithmicResponse,
      activeTrack,
      targetTrack,
      durationBars,
      source: 'algorithmic_architect',
    });
  } catch (error) {
    console.error('AI Transition Plan error:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to generate Hard Techno transition protocol',
    });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[KlangStripe] Server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
